<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Handle hotel operations (add, edit, delete)
$operation_message = "";

// Delete hotel if requested
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $hotel_id = (int)$_GET['delete'];
    
    // Check if hotel exists and can be deleted (no active bookings)
    $check_query = "SELECT COUNT(*) FROM bookings b 
                    JOIN rooms r ON b.room_id = r.room_id 
                    JOIN room_types rt ON r.room_type_id = rt.room_type_id 
                    WHERE rt.hotel_id = :hotel_id AND b.booking_status IN ('confirmed', 'pending')";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bindParam(':hotel_id', $hotel_id);
    $check_stmt->execute();
    
    if ($check_stmt->fetchColumn() > 0) {
        $_SESSION['error_message'] = "Cannot delete hotel. There are active bookings associated with this hotel.";
    } else {
        // Delete associated rooms, room types, and then hotel
        try {
            // Start transaction
            $conn->beginTransaction();
            
            // Delete associated rooms first
            $delete_rooms_query = "DELETE r FROM rooms r 
                                  JOIN room_types rt ON r.room_type_id = rt.room_type_id 
                                  WHERE rt.hotel_id = :hotel_id";
            $delete_rooms_stmt = $conn->prepare($delete_rooms_query);
            $delete_rooms_stmt->bindParam(':hotel_id', $hotel_id);
            $delete_rooms_stmt->execute();
            
            // Delete room types
            $delete_room_types_query = "DELETE FROM room_types WHERE hotel_id = :hotel_id";
            $delete_room_types_stmt = $conn->prepare($delete_room_types_query);
            $delete_room_types_stmt->bindParam(':hotel_id', $hotel_id);
            $delete_room_types_stmt->execute();
            
            // Delete reviews associated with the hotel
            $delete_reviews_query = "DELETE FROM reviews WHERE hotel_id = :hotel_id";
            $delete_reviews_stmt = $conn->prepare($delete_reviews_query);
            $delete_reviews_stmt->bindParam(':hotel_id', $hotel_id);
            $delete_reviews_stmt->execute();
            
            // Finally delete the hotel
            $delete_hotel_query = "DELETE FROM hotels WHERE hotel_id = :hotel_id";
            $delete_hotel_stmt = $conn->prepare($delete_hotel_query);
            $delete_hotel_stmt->bindParam(':hotel_id', $hotel_id);
            $delete_hotel_stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            $_SESSION['success_message'] = "Hotel deleted successfully!";
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollBack();
            $_SESSION['error_message'] = "Error deleting hotel: " . $e->getMessage();
        }
    }
    
    // Redirect to avoid resubmission
    redirect(SITE_URL . '/admin/hotels.php');
}

// Get all hotels with rating information
$query = "
    SELECT h.*, 
           AVG(r.rating) as average_rating,
           COUNT(DISTINCT r.review_id) as review_count
    FROM hotels h
    LEFT JOIN reviews r ON h.hotel_id = r.hotel_id
    GROUP BY h.hotel_id
    ORDER BY h.hotel_id ASC
";
$stmt = $conn->prepare($query);
$stmt->execute();
$hotels = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Hotels</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="hotel_add.php" class="btn btn-sm btn-primary">
                        <i class="fas fa-plus me-1"></i> Add New Hotel
                    </a>
                </div>
            </div>
            
            <!-- Hotels List -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-hotel me-1"></i>
                    All Hotels
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="hotelsTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Location</th>
                                    <th>Rating</th>
                                    <th>Rooms</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($hotels as $hotel): ?>
                                    <tr>
                                        <td><?php echo $hotel['hotel_id']; ?></td>
                                        <td>
                                            <img src="<?php echo !empty($hotel['image_path']) ? '../' . $hotel['image_path'] : '../assets/img/hotel-placeholder.jpg'; ?>" 
                                                alt="<?php echo $hotel['hotel_name']; ?>" class="img-thumbnail" width="80">
                                        </td>
                                        <td><?php echo $hotel['hotel_name']; ?></td>
                                        <td><?php echo $hotel['location']; ?></td>
                                        <td>
                                            <?php 
                                            $rating = $hotel['average_rating'] !== null ? round($hotel['average_rating'], 1) : null;
                                            echo $rating !== null ? $rating : 'No ratings';
                                            ?>
                                            <small class="text-muted">
                                                (<?php echo $hotel['review_count']; ?> reviews)
                                            </small>
                                        </td>
                                        <td>
                                            <?php
                                            // Count rooms for this hotel
                                            $room_query = "SELECT COUNT(*) FROM rooms r 
                                                          JOIN room_types rt ON r.room_type_id = rt.room_type_id 
                                                          WHERE rt.hotel_id = :hotel_id";
                                            $room_stmt = $conn->prepare($room_query);
                                            $room_stmt->bindParam(':hotel_id', $hotel['hotel_id']);
                                            $room_stmt->execute();
                                            echo $room_stmt->fetchColumn();
                                            ?>
                                        </td>
                                        <td>
                                            <a href="hotel_edit.php?id=<?php echo $hotel['hotel_id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="hotel_view.php?id=<?php echo $hotel['hotel_id']; ?>" class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="rooms.php?hotel_id=<?php echo $hotel['hotel_id']; ?>" class="btn btn-sm btn-success">
                                                <i class="fas fa-bed"></i>
                                            </a>
                                            <a href="hotels.php?delete=<?php echo $hotel['hotel_id']; ?>" class="btn btn-sm btn-danger"
                                               onclick="return confirm('Are you sure you want to delete this hotel? This action cannot be undone.')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($hotels)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No hotels found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#hotelsTable').DataTable();
});
</script>

<?php include '../includes/footer.php'; ?>
