<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Get filter parameter for hotel_id if exists
$filter_hotel_id = isset($_GET['hotel_id']) ? (int)$_GET['hotel_id'] : null;

// Delete room type if requested
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $room_type_id = (int)$_GET['delete'];
    
    // Check if room type can be deleted (no rooms assigned)
    $check_query = "SELECT COUNT(*) FROM rooms WHERE room_type_id = :room_type_id";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bindParam(':room_type_id', $room_type_id);
    $check_stmt->execute();
    
    if ($check_stmt->fetchColumn() > 0) {
        $_SESSION['error_message'] = "Cannot delete room type. There are rooms assigned to this type.";
    } else {
        try {
            // Delete the room type
            $delete_query = "DELETE FROM room_types WHERE room_type_id = :room_type_id";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->bindParam(':room_type_id', $room_type_id);
            $delete_stmt->execute();
            
            $_SESSION['success_message'] = "Room type deleted successfully!";
        } catch (Exception $e) {
            $_SESSION['error_message'] = "Error deleting room type: " . $e->getMessage();
        }
    }
    
    // Redirect to avoid resubmission
    $redirect_url = 'room_types.php';
    if ($filter_hotel_id) {
        $redirect_url .= '?hotel_id=' . $filter_hotel_id;
    }
    redirect(SITE_URL . '/admin/' . $redirect_url);
}

// Build query based on filters
$params = [];
$query = "
    SELECT rt.*, h.hotel_name, h.hotel_id,
           (SELECT COUNT(*) FROM rooms r WHERE r.room_type_id = rt.room_type_id) as rooms_count
    FROM room_types rt
    JOIN hotels h ON rt.hotel_id = h.hotel_id
";

if ($filter_hotel_id) {
    $query .= " WHERE rt.hotel_id = :hotel_id";
    $params[':hotel_id'] = $filter_hotel_id;
}

$query .= " ORDER BY h.hotel_name, rt.type_name";

$stmt = $conn->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$room_types = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get hotel details if filtering by hotel
$hotel_name = "";
if ($filter_hotel_id) {
    $hotel_query = "SELECT hotel_name FROM hotels WHERE hotel_id = :hotel_id";
    $hotel_stmt = $conn->prepare($hotel_query);
    $hotel_stmt->bindParam(':hotel_id', $filter_hotel_id);
    $hotel_stmt->execute();
    $hotel_result = $hotel_stmt->fetch(PDO::FETCH_ASSOC);
    if ($hotel_result) {
        $hotel_name = $hotel_result['hotel_name'];
    }
}

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <?php if (!empty($hotel_name)): ?>
                        Room Types for <?php echo $hotel_name; ?>
                    <?php else: ?>
                        Manage Room Types
                    <?php endif; ?>
                </h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <?php if ($filter_hotel_id): ?>
                        <a href="room_type_add.php?hotel_id=<?php echo $filter_hotel_id; ?>" class="btn btn-sm btn-primary me-2">
                            <i class="fas fa-plus me-1"></i> Add Room Type
                        </a>
                        <a href="room_types.php" class="btn btn-sm btn-secondary">
                            <i class="fas fa-list me-1"></i> Show All Room Types
                        </a>
                    <?php else: ?>
                        <a href="room_type_add.php" class="btn btn-sm btn-primary">
                            <i class="fas fa-plus me-1"></i> Add Room Type
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Room Types List -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-bed me-1"></i>
                    <?php echo !empty($hotel_name) ? 'Room Types in ' . $hotel_name : 'All Room Types'; ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="roomTypesTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Hotel</th>
                                    <th>Image</th>
                                    <th>Type Name</th>
                                    <th>Price/Night</th>
                                    <th>Capacity</th>
                                    <th>Rooms</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($room_types as $type): ?>
                                    <?php $room_type_name = isset($type['room_type_name']) ? $type['room_type_name'] : ''; // Provide a default value ?>
                                    <tr>
                                        <td><?php echo $type['room_type_id']; ?></td>
                                        <td><?php echo $type['hotel_name']; ?></td>
                                        <td>
                                            <img src="<?php echo !empty($type['image_path']) ? '../' . $type['image_path'] : '../assets/img/room-placeholder.jpg'; ?>" 
                                                alt="<?php echo htmlspecialchars($room_type_name); ?>" class="img-thumbnail" width="80">
                                        </td>
                                        <td><?php echo htmlspecialchars($room_type_name); ?></td>
                                        <td>$<?php echo number_format($type['price'], 2); ?></td>
                                        <td><?php echo $type['capacity']; ?> persons</td>
                                        <td><?php echo $type['rooms_count']; ?></td>
                                        <td>
                                            <a href="room_type_edit.php?id=<?php echo $type['room_type_id']; ?><?php echo $filter_hotel_id ? '&hotel_id='.$filter_hotel_id : ''; ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if ($type['rooms_count'] == 0): ?>
                                                <a href="room_types.php?delete=<?php echo $type['room_type_id']; ?><?php echo $filter_hotel_id ? '&hotel_id='.$filter_hotel_id : ''; ?>" 
                                                   class="btn btn-sm btn-danger"
                                                   onclick="return confirm('Are you sure you want to delete this room type?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-danger" disabled title="Cannot delete. There are rooms assigned to this type.">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($room_types)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No room types found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#roomTypesTable').DataTable();
});
</script>

<?php include '../includes/footer.php'; ?>
