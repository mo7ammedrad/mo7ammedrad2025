<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Handle review deletion
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $review_id = (int)$_GET['delete'];
    
    try {
        $delete_query = "DELETE FROM reviews WHERE review_id = :review_id";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->bindParam(':review_id', $review_id);
        $delete_stmt->execute();
        
        $_SESSION['success_message'] = "Review deleted successfully!";
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Error deleting review: " . $e->getMessage();
    }
    
    // Redirect to avoid resubmission
    redirect(SITE_URL . '/admin/reviews.php');
}

// Get filter parameters
$hotel_filter = isset($_GET['hotel_id']) ? (int)$_GET['hotel_id'] : null;
$rating_filter = isset($_GET['rating']) ? (int)$_GET['rating'] : null;

// Build query based on filters
$params = [];
$query = "
    SELECT r.*, u.username, u.full_name, h.hotel_name
    FROM reviews r
    JOIN users u ON r.user_id = u.user_id
    JOIN hotels h ON r.hotel_id = h.hotel_id
    WHERE 1=1
";

if ($hotel_filter) {
    $query .= " AND r.hotel_id = :hotel_id";
    $params[':hotel_id'] = $hotel_filter;
}

if ($rating_filter) {
    $query .= " AND r.rating = :rating";
    $params[':rating'] = $rating_filter;
}

$query .= " ORDER BY r.review_date DESC";

$stmt = $conn->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all hotels for filter dropdown
$hotels_query = "SELECT hotel_id, hotel_name FROM hotels ORDER BY hotel_name";
$hotels_stmt = $conn->prepare($hotels_query);
$hotels_stmt->execute();
$hotels = $hotels_stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="room_types.php">
                            <i class="fas fa-door-open me-2"></i> Room Types
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Reviews</h1>
            </div>
            
            <!-- Review Filters -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-filter me-1"></i>
                    Filter Reviews
                </div>
                <div class="card-body">
                    <form action="reviews.php" method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label for="hotel_id" class="form-label">Hotel</label>
                            <select class="form-select" id="hotel_id" name="hotel_id">
                                <option value="">All Hotels</option>
                                <?php foreach ($hotels as $hotel): ?>
                                    <option value="<?php echo $hotel['hotel_id']; ?>" 
                                        <?php echo $hotel_filter == $hotel['hotel_id'] ? 'selected' : ''; ?>>
                                        <?php echo $hotel['hotel_name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="rating" class="form-label">Rating</label>
                            <select class="form-select" id="rating" name="rating">
                                <option value="">All Ratings</option>
                                <?php for ($i = 5; $i >= 1; $i--): ?>
                                    <option value="<?php echo $i; ?>" <?php echo $rating_filter == $i ? 'selected' : ''; ?>>
                                        <?php echo $i; ?> Star<?php echo $i > 1 ? 's' : ''; ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">Apply Filters</button>
                            <a href="reviews.php" class="btn btn-secondary">Reset</a>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Reviews List -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-star me-1"></i>
                    Customer Reviews
                </div>
                <div class="card-body">
                    <?php if (count($reviews) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover" id="reviewsTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Hotel</th>
                                        <th>User</th>
                                        <th>Rating</th>
                                        <th>Comment</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($reviews as $review): ?>
                                        <tr>
                                            <td><?php echo $review['review_id']; ?></td>
                                            <td><?php echo $review['hotel_name']; ?></td>
                                            <td><?php echo $review['full_name']; ?></td>
                                            <td>
                                                <div class="rating-stars">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <i class="fas fa-star <?php echo $i <= $review['rating'] ? 'text-warning' : 'text-muted'; ?>"></i>
                                                    <?php endfor; ?>
                                                </div>
                                            </td>
                                            <td><?php echo nl2br(htmlspecialchars($review['comment'])); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($review['review_date'])); ?></td>
                                            <td>
                                                <a href="reviews.php?delete=<?php echo $review['review_id']; ?>" 
                                                   class="btn btn-sm btn-danger"
                                                   onclick="return confirm('Are you sure you want to delete this review?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">No reviews found matching your criteria.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#reviewsTable').DataTable({
        order: [[5, 'desc']]
    });
});
</script>

<?php include '../includes/footer.php'; ?>
