<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Get filter parameter for hotel_id if exists
$filter_hotel_id = isset($_GET['hotel_id']) ? (int)$_GET['hotel_id'] : null;

// Delete room if requested
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $room_id = (int)$_GET['delete'];
    
    // Check if room can be deleted (no active bookings)
    $check_query = "SELECT COUNT(*) FROM bookings WHERE room_id = :room_id AND booking_status IN ('confirmed', 'pending')";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bindParam(':room_id', $room_id);
    $check_stmt->execute();
    
    if ($check_stmt->fetchColumn() > 0) {
        $_SESSION['error_message'] = "Cannot delete room. There are active bookings for this room.";
    } else {
        try {
            // Delete the room
            $delete_query = "DELETE FROM rooms WHERE room_id = :room_id";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->bindParam(':room_id', $room_id);
            $delete_stmt->execute();
            
            $_SESSION['success_message'] = "Room deleted successfully!";
        } catch (Exception $e) {
            $_SESSION['error_message'] = "Error deleting room: " . $e->getMessage();
        }
    }
    
    // Redirect to avoid resubmission
    $redirect_url = 'rooms.php';
    if ($filter_hotel_id) {
        $redirect_url .= '?hotel_id=' . $filter_hotel_id;
    }
    redirect(SITE_URL . '/admin/' . $redirect_url);
}

// Build query based on filters
$params = [];
$query = "
    SELECT r.*, rt.type_name AS room_type_name, rt.price, h.hotel_name, h.hotel_id,
           (SELECT COUNT(*) FROM bookings b WHERE b.room_id = r.room_id AND b.booking_status IN ('confirmed', 'pending')) as active_bookings
    FROM rooms r
    JOIN room_types rt ON r.room_type_id = rt.room_type_id
    JOIN hotels h ON rt.hotel_id = h.hotel_id
";

if ($filter_hotel_id) {
    $query .= " WHERE h.hotel_id = :hotel_id";
    $params[':hotel_id'] = $filter_hotel_id;
}

$query .= " ORDER BY h.hotel_name, r.room_number";

$stmt = $conn->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get hotel details if filtering by hotel
$hotel_name = "";
if ($filter_hotel_id) {
    $hotel_query = "SELECT hotel_name FROM hotels WHERE hotel_id = :hotel_id";
    $hotel_stmt = $conn->prepare($hotel_query);
    $hotel_stmt->bindParam(':hotel_id', $filter_hotel_id);
    $hotel_stmt->execute();
    $hotel_result = $hotel_stmt->fetch(PDO::FETCH_ASSOC);
    if ($hotel_result) {
        $hotel_name = $hotel_result['hotel_name'];
    }
}

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">
                    <?php if (!empty($hotel_name)): ?>
                        Rooms for <?php echo $hotel_name; ?>
                    <?php else: ?>
                        Manage Rooms
                    <?php endif; ?>
                </h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <?php if ($filter_hotel_id): ?>
                        <a href="room_add.php?hotel_id=<?php echo $filter_hotel_id; ?>" class="btn btn-sm btn-primary me-2">
                            <i class="fas fa-plus me-1"></i> Add Room
                        </a>
                        <a href="rooms.php" class="btn btn-sm btn-secondary">
                            <i class="fas fa-list me-1"></i> Show All Rooms
                        </a>
                    <?php else: ?>
                        <a href="room_add.php" class="btn btn-sm btn-primary">
                            <i class="fas fa-plus me-1"></i> Add Room
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Rooms List -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-bed me-1"></i>
                    <?php echo !empty($hotel_name) ? 'Rooms in ' . $hotel_name : 'All Rooms'; ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="roomsTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Hotel</th>
                                    <th>Room Number</th>
                                    <th>Room Type</th>
                                    <th>Capacity</th>
                                    <th>Price/Night</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rooms as $room): ?>
                                    <tr>
                                        <td><?php echo $room['room_id']; ?></td>
                                        <td><?php echo $room['hotel_name']; ?></td>
                                        <td><?php echo $room['room_number']; ?></td>
                                        <td><?php echo $room['room_type_name']; ?></td>
                                        <td><?php echo $room['capacity']; ?> persons</td>
                                        <?php $price_per_night = isset($room['price_per_night']) ? $room['price_per_night'] : 0.00; ?>
                                        <td>$<?php echo number_format($price_per_night, 2); ?></td>
                                        <td>
                                            <?php if ($room['active_bookings'] > 0): ?>
                                                <span class="badge bg-warning">Booked</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Available</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="room_edit.php?id=<?php echo $room['room_id']; ?><?php echo $filter_hotel_id ? '&hotel_id='.$filter_hotel_id : ''; ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="rooms.php?delete=<?php echo $room['room_id']; ?><?php echo $filter_hotel_id ? '&hotel_id='.$filter_hotel_id : ''; ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Are you sure you want to delete this room?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($rooms)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No rooms found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#roomsTable').DataTable();
});
</script>

<?php include '../includes/footer.php'; ?>
