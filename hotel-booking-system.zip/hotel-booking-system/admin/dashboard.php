<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Get summary statistics
$stats_query = "
    SELECT 
        (SELECT COUNT(*) FROM hotels) as total_hotels,
        (SELECT COUNT(*) FROM room_types) as total_room_types,
        (SELECT COUNT(*) FROM users WHERE user_type = 'customer') as total_customers,
        (SELECT COUNT(*) FROM bookings) as total_bookings,
        (SELECT COUNT(*) FROM bookings WHERE booking_status = 'confirmed') as confirmed_bookings,
        (SELECT COUNT(*) FROM bookings WHERE booking_status = 'pending') as pending_bookings,
        (SELECT SUM(total_price) FROM bookings WHERE booking_status IN ('confirmed', 'completed')) as total_revenue
";
$stats_stmt = $conn->prepare($stats_query);
$stats_stmt->execute();
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

// Get recent bookings
$recent_bookings_query = "
    SELECT b.booking_id, b.booking_date, b.check_in_date, b.check_out_date, 
           b.total_price, b.booking_status, b.payment_status,
           u.username, u.full_name,
           h.hotel_name, r.room_number
    FROM bookings b
    JOIN users u ON b.user_id = u.user_id
    JOIN rooms r ON b.room_id = r.room_id
    JOIN room_types rt ON r.room_type_id = rt.room_type_id
    JOIN hotels h ON rt.hotel_id = h.hotel_id
    ORDER BY b.booking_date DESC
    LIMIT 5";
$recent_bookings_stmt = $conn->prepare($recent_bookings_query);
$recent_bookings_stmt->execute();
$recent_bookings = $recent_bookings_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent users
$recent_users_query = "
    SELECT user_id, username, email, full_name, created_at
    FROM users
    WHERE user_type = 'customer'
    ORDER BY created_at DESC
    LIMIT 5";
$recent_users_stmt = $conn->prepare($recent_users_query);
$recent_users_stmt->execute();
$recent_users = $recent_users_stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="room_types.php">
                            <i class="fas fa-door-open me-2"></i> Room Types
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Admin Dashboard</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                        <i class="fas fa-calendar me-1"></i> This week
                    </button>
                </div>
            </div>
            
            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-4">
                    <div class="card dashboard-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-muted">Total Hotels</h6>
                                    <h2 class="mb-0"><?php echo $stats['total_hotels']; ?></h2>
                                </div>
                                <div class="icon bg-light-primary rounded-circle p-3">
                                    <i class="fas fa-hotel text-primary"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-4">
                    <div class="card dashboard-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-muted">Total Customers</h6>
                                    <h2 class="mb-0"><?php echo $stats['total_customers']; ?></h2>
                                </div>
                                <div class="icon bg-light-success rounded-circle p-3">
                                    <i class="fas fa-users text-success"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-4">
                    <div class="card dashboard-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-muted">Total Bookings</h6>
                                    <h2 class="mb-0"><?php echo $stats['total_bookings']; ?></h2>
                                </div>
                                <div class="icon bg-light-info rounded-circle p-3">
                                    <i class="fas fa-calendar-check text-info"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-4">
                    <div class="card dashboard-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-muted">Total Revenue</h6>
                                    <h2 class="mb-0">$<?php echo $stats['total_revenue']; ?></h2>
                                </div>
                                <div class="icon bg-light-warning rounded-circle p-3">
                                    <i class="fas fa-dollar-sign text-warning"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Bookings -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Bookings</h5>
                    <a href="bookings.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Customer</th>
                                    <th>Hotel & Room</th>
                                    <th>Check-in / Check-out</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($recent_bookings) > 0): ?>
                                    <?php foreach ($recent_bookings as $booking): ?>
                                        <tr>
                                            <td><?php echo $booking['booking_id']; ?></td>
                                            <td><?php echo $booking['full_name']; ?></td>
                                            <td>
                                                <strong><?php echo $booking['hotel_name']; ?></strong><br>
                                                <small class="text-muted">Room <?php echo $booking['room_number']; ?></small>
                                            </td>
                                            <td>
                                                <?php echo formatDate($booking['check_in_date']); ?><br>
                                                <small class="text-muted"><?php echo formatDate($booking['check_out_date']); ?></small>
                                            </td>
                                            <td>$<?php echo number_format($booking['total_price'], 2); ?></td>
                                            <td>
                                                <?php 
                                                $status_class = 'secondary';
                                                if ($booking['booking_status'] === 'confirmed') {
                                                    $status_class = 'success';
                                                } elseif ($booking['booking_status'] === 'cancelled') {
                                                    $status_class = 'danger';
                                                } elseif ($booking['booking_status'] === 'pending') {
                                                    $status_class = 'warning';
                                                }
                                                ?>
                                                <span class="badge bg-<?php echo $status_class; ?>">
                                                    <?php echo ucfirst($booking['booking_status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="booking_details.php?id=<?php echo $booking['booking_id']; ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No bookings found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <!-- Recent Users -->
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Recent Users</h5>
                            <a href="users.php" class="btn btn-sm btn-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Joined Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (count($recent_users) > 0): ?>
                                            <?php foreach ($recent_users as $user): ?>
                                                <tr>
                                                    <td><?php echo $user['full_name']; ?></td>
                                                    <td><?php echo $user['email']; ?></td>
                                                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="3" class="text-center">No users found</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Booking Stats -->
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="mb-0">Booking Statistics</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="bookingChart"></canvas>
                            <div class="text-center mt-4">
                                <div class="d-inline-block me-3">
                                    <div class="d-flex align-items-center">
                                        <span class="bg-success rounded-circle d-inline-block me-2" style="width: 10px; height: 10px;"></span>
                                        <span>Confirmed (<?php echo $stats['confirmed_bookings']; ?>)</span>
                                    </div>
                                </div>
                                <div class="d-inline-block me-3">
                                    <div class="d-flex align-items-center">
                                        <span class="bg-warning rounded-circle d-inline-block me-2" style="width: 10px; height: 10px;"></span>
                                        <span>Pending (<?php echo $stats['pending_bookings']; ?>)</span>
                                    </div>
                                </div>
                                <div class="d-inline-block">
                                    <div class="d-flex align-items-center">
                                        <span class="bg-secondary rounded-circle d-inline-block me-2" style="width: 10px; height: 10px;"></span>
                                        <span>Others (<?php echo $stats['total_bookings'] - $stats['confirmed_bookings'] - $stats['pending_bookings']; ?>)</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js Script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Booking Chart
    const ctx = document.getElementById('bookingChart').getContext('2d');
    const bookingChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Confirmed', 'Pending', 'Others'],
            datasets: [{
                data: [
                    <?php echo $stats['confirmed_bookings']; ?>,
                    <?php echo $stats['pending_bookings']; ?>,
                    <?php echo $stats['total_bookings'] - $stats['confirmed_bookings'] - $stats['pending_bookings']; ?>
                ],
                backgroundColor: [
                    '#28a745',
                    '#ffc107',
                    '#6c757d'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            cutout: '70%'
        }
    });
</script>

<?php include '../includes/footer.php'; ?>
