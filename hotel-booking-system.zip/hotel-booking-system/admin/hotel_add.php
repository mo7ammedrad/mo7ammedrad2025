
<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Initialize variables
$hotel_name = "";
$location = "";
$description = "";
$image_path = "";
$errors = [];

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize inputs
    $hotel_name = cleanInput($_POST['hotel_name']);
    $location = cleanInput($_POST['location']);
    $description = cleanInput($_POST['description']);
    
    // Check for required fields
    if (empty($hotel_name)) {
        $errors[] = "Hotel name is required";
    }
    if (empty($location)) {
        $errors[] = "Location is required";
    }
    
    // Handle image upload
    if (isset($_FILES['hotel_image']) && $_FILES['hotel_image']['error'] == 0) {
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        $file_name = $_FILES['hotel_image']['name'];
        $file_size = $_FILES['hotel_image']['size'];
        $file_tmp = $_FILES['hotel_image']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Check file extension
        if (!in_array($file_ext, $allowed_ext)) {
            $errors[] = "Extension not allowed: " . $file_ext . " - Please upload images only (jpg, jpeg, png, gif)";
        }
        
        // Check file size (5MB max)
        if ($file_size > 5000000) {
            $errors[] = "File size must be less than 5MB";
        }
        
        // If no errors, move the uploaded file
        if (empty($errors)) {
            $new_file_name = uniqid() . "." . $file_ext;
            $upload_path = "../assets/img/hotels/" . $new_file_name;
            $image_path = "assets/img/hotels/" . $new_file_name;
            
            // Create directory if it doesn't exist
            if (!file_exists("../assets/img/hotels/")) {
                mkdir("../assets/img/hotels/", 0777, true);
            }
            
            // Move the file
            if (move_uploaded_file($file_tmp, $upload_path)) {
                // File uploaded successfully
            } else {
                $errors[] = "Error uploading file";
                $image_path = "";
            }
        }
    }
    
    // If no errors, insert the hotel into the database
    if (empty($errors)) {
        try {
            $query = "INSERT INTO hotels (hotel_name, location, description, image_path) VALUES (:hotel_name, :location, :description, :image_path)";
            $stmt = $conn->prepare($query);
            
            $stmt->bindParam(':hotel_name', $hotel_name);
            $stmt->bindParam(':location', $location);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':image_path', $image_path);
            
            if ($stmt->execute()) {
                $_SESSION['success_message'] = "Hotel added successfully!";
                redirect(SITE_URL . '/admin/hotels.php');
            } else {
                $errors[] = "Error adding hotel";
            }
        } catch (Exception $e) {
            $errors[] = "Error: " . $e->getMessage();
        }
    }
}

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Add New Hotel</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="hotels.php" class="btn btn-sm btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Back to Hotels
                    </a>
                </div>
            </div>
            
            <!-- Display Errors -->
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <!-- Add Hotel Form -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-hotel me-1"></i>
                    Hotel Information
                </div>
                <div class="card-body">
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="hotel_name" class="form-label">Hotel Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="hotel_name" name="hotel_name" value="<?php echo htmlspecialchars($hotel_name); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="location" class="form-label">Location <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="location" name="location" value="<?php echo htmlspecialchars($location); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4"><?php echo htmlspecialchars($description); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="hotel_image" class="form-label">Hotel Image</label>
                            <input type="file" class="form-control" id="hotel_image" name="hotel_image">
                            <div class="form-text">Upload an image for the hotel. Recommended size: 1200x800 pixels.</div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="reset" class="btn btn-outline-secondary me-md-2">Reset</button>
                            <button type="submit" class="btn btn-primary">Add Hotel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
