
<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Initialize variables
$room_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$hotel_id = isset($_GET['hotel_id']) ? (int)$_GET['hotel_id'] : 0;
$room_number = "";
$room_type_id = "";
$capacity = 0;
$errors = [];

// Check if room_id is valid
if ($room_id <= 0) {
    $_SESSION['error_message'] = "Invalid room ID";
    redirect(SITE_URL . '/admin/rooms.php');
}

// Get room data
$query = "SELECT r.*, rt.room_type_id, rt.hotel_id 
          FROM rooms r 
          JOIN room_types rt ON r.room_type_id = rt.room_type_id 
          WHERE r.room_id = :room_id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':room_id', $room_id);
$stmt->execute();

$room = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$room) {
    $_SESSION['error_message'] = "Room not found";
    redirect(SITE_URL . '/admin/rooms.php');
}

// Set hotel_id from room data if not provided in URL
if ($hotel_id == 0) {
    $hotel_id = $room['hotel_id'];
}

// Get all hotels for the dropdown
$hotels_query = "SELECT hotel_id, hotel_name FROM hotels ORDER BY hotel_name";
$hotels_stmt = $conn->prepare($hotels_query);
$hotels_stmt->execute();
$hotels = $hotels_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get room types based on selected hotel
$room_types_query = "SELECT room_type_id, room_type_name FROM room_types WHERE hotel_id = :hotel_id ORDER BY room_type_name";
$room_types_stmt = $conn->prepare($room_types_query);
$room_types_stmt->bindParam(':hotel_id', $hotel_id);
$room_types_stmt->execute();
$room_types = $room_types_stmt->fetchAll(PDO::FETCH_ASSOC);

// Set values from room data
$room_number = $room['room_number'];
$room_type_id = $room['room_type_id'];
$capacity = $room['capacity'];

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize inputs
    $hotel_id = isset($_POST['hotel_id']) ? (int)$_POST['hotel_id'] : 0;
    $room_type_id = isset($_POST['room_type_id']) ? (int)$_POST['room_type_id'] : 0;
    $room_number = cleanInput($_POST['room_number']);
    $capacity = isset($_POST['capacity']) ? (int)$_POST['capacity'] : 1;
    
    // Check for required fields
    if ($hotel_id <= 0) {
        $errors[] = "Hotel is required";
    }
    if ($room_type_id <= 0) {
        $errors[] = "Room type is required";
    }
    if (empty($room_number)) {
        $errors[] = "Room number is required";
    }
    if ($capacity <= 0) {
        $errors[] = "Capacity must be at least 1";
    }
    
    // Check if room number already exists for this hotel (excluding current room)
    if (empty($errors)) {
        $check_query = "SELECT COUNT(*) FROM rooms r
                      JOIN room_types rt ON r.room_type_id = rt.room_type_id
                      WHERE rt.hotel_id = :hotel_id AND r.room_number = :room_number AND r.room_id != :room_id";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->bindParam(':hotel_id', $hotel_id);
        $check_stmt->bindParam(':room_number', $room_number);
        $check_stmt->bindParam(':room_id', $room_id);
        $check_stmt->execute();
        
        if ($check_stmt->fetchColumn() > 0) {
            $errors[] = "Room number already exists for this hotel";
        }
    }
    
    // If no errors, update the room in the database
    if (empty($errors)) {
        try {
            $query = "UPDATE rooms SET room_type_id = :room_type_id, room_number = :room_number, capacity = :capacity WHERE room_id = :room_id";
            $stmt = $conn->prepare($query);
            
            $stmt->bindParam(':room_type_id', $room_type_id);
            $stmt->bindParam(':room_number', $room_number);
            $stmt->bindParam(':capacity', $capacity);
            $stmt->bindParam(':room_id', $room_id);
            
            if ($stmt->execute()) {
                $_SESSION['success_message'] = "Room updated successfully!";
                redirect(SITE_URL . '/admin/rooms.php' . ($hotel_id > 0 ? '?hotel_id=' . $hotel_id : ''));
            } else {
                $errors[] = "Error updating room";
            }
        } catch (Exception $e) {
            $errors[] = "Error: " . $e->getMessage();
        }
    }
    
    // If there were errors, reload room types for the selected hotel
    if (!empty($errors) && $hotel_id > 0) {
        $room_types_query = "SELECT room_type_id, room_type_name FROM room_types WHERE hotel_id = :hotel_id ORDER BY room_type_name";
        $room_types_stmt = $conn->prepare($room_types_query);
        $room_types_stmt->bindParam(':hotel_id', $hotel_id);
        $room_types_stmt->execute();
        $room_types = $room_types_stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Edit Room</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="<?php echo $hotel_id > 0 ? 'rooms.php?hotel_id=' . $hotel_id : 'rooms.php'; ?>" class="btn btn-sm btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Back to Rooms
                    </a>
                </div>
            </div>
            
            <!-- Display Errors -->
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <!-- Edit Room Form -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-bed me-1"></i>
                    Room Information
                </div>
                <div class="card-body">
                    <form action="<?php echo $_SERVER['PHP_SELF'] . '?id=' . $room_id . ($hotel_id > 0 ? '&hotel_id=' . $hotel_id : ''); ?>" method="post">
                        <div class="mb-3">
                            <label for="hotel_id" class="form-label">Hotel <span class="text-danger">*</span></label>
                            <select class="form-select" id="hotel_id" name="hotel_id" required onchange="this.form.submit()">
                                <option value="">Select Hotel</option>
                                <?php foreach ($hotels as $hotel): ?>
                                    <option value="<?php echo $hotel['hotel_id']; ?>" <?php echo $hotel_id == $hotel['hotel_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($hotel['hotel_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="room_type_id" class="form-label">Room Type <span class="text-danger">*</span></label>
                            <select class="form-select" id="room_type_id" name="room_type_id" required>
                                <option value="">Select Room Type</option>
                                <?php foreach ($room_types as $type): ?>
                                    <option value="<?php echo $type['room_type_id']; ?>" <?php echo $room_type_id == $type['room_type_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($type['room_type_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (count($room_types) == 0): ?>
                                <div class="form-text text-danger">No room types available for selected hotel.</div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3">
                            <label for="room_number" class="form-label">Room Number <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="room_number" name="room_number" value="<?php echo htmlspecialchars($room_number); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="capacity" class="form-label">Capacity <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="capacity" name="capacity" min="1" max="10" value="<?php echo $capacity; ?>" required>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="<?php echo $hotel_id > 0 ? 'rooms.php?hotel_id=' . $hotel_id : 'rooms.php'; ?>" class="btn btn-outline-secondary me-md-2">Cancel</a>
                            <button type="submit" class="btn btn-primary">Update Room</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
