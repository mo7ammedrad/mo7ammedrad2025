<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Handle user status toggle (active/inactive)
if (isset($_GET['toggle_status']) && !empty($_GET['toggle_status'])) {
    $user_id = (int)$_GET['toggle_status'];
    
    // Don't allow toggling the admin account
    $check_query = "SELECT username, is_active FROM users WHERE user_id = :user_id";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bindParam(':user_id', $user_id);
    $check_stmt->execute();
    $user = $check_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && $user['username'] !== 'admin') {
        $new_status = $user['is_active'] ? 0 : 1;
        
        $update_query = "UPDATE users SET is_active = :is_active WHERE user_id = :user_id";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bindParam(':is_active', $new_status);
        $update_stmt->bindParam(':user_id', $user_id);
        
        if ($update_stmt->execute()) {
            $_SESSION['success_message'] = "User status updated successfully!";
        } else {
            $_SESSION['error_message'] = "Error updating user status.";
        }
    } else if ($user && $user['username'] === 'admin') {
        $_SESSION['error_message'] = "Cannot modify the admin account status.";
    }
    
    // Redirect to avoid resubmission
    redirect(SITE_URL . '/admin/users.php');
}

// Get all users
$query = "
    SELECT u.*, 
           COUNT(DISTINCT b.booking_id) as total_bookings,
           COUNT(DISTINCT r.review_id) as total_reviews
    FROM users u
    LEFT JOIN bookings b ON u.user_id = b.user_id
    LEFT JOIN reviews r ON u.user_id = r.user_id
    GROUP BY u.user_id
    ORDER BY u.created_at DESC
";
$stmt = $conn->prepare($query);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="room_types.php">
                            <i class="fas fa-door-open me-2"></i> Room Types
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Users</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="user_add.php" class="btn btn-sm btn-primary">
                        <i class="fas fa-user-plus me-1"></i> Add New User
                    </a>
                </div>
            </div>
            
            <!-- Users List -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-users me-1"></i>
                    All Users
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="usersTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>User Type</th>
                                    <th>Status</th>
                                    <th>Joined</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo $user['user_id']; ?></td>
                                        <td><?php echo $user['full_name']; ?></td>
                                        <td><?php echo $user['username']; ?></td>
                                        <td><?php echo $user['email']; ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $user['user_type'] === 'admin' ? 'danger' : 'info'; ?>">
                                                <?php echo ucfirst($user['user_type']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if (isset($user['is_active'])): ?>
                                                <span class="badge bg-<?php echo $user['is_active'] ? 'success' : 'secondary'; ?>">
                                                    <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                        <td>
                                            <a href="user_view.php?id=<?php echo $user['user_id']; ?>" class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="user_edit.php?id=<?php echo $user['user_id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if ($user['username'] !== 'admin'): ?>
                                                <a href="users.php?toggle_status=<?php echo $user['user_id']; ?>" 
                                                   class="btn btn-sm <?php echo isset($user['is_active']) && $user['is_active'] ? 'btn-warning' : 'btn-success'; ?>"
                                                   title="<?php echo isset($user['is_active']) && $user['is_active'] ? 'Deactivate' : 'Activate'; ?> user">
                                                    <i class="fas fa-<?php echo isset($user['is_active']) && $user['is_active'] ? 'ban' : 'check'; ?>"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($users)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No users found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#usersTable').DataTable();
});
</script>

<?php include '../includes/footer.php'; ?>
