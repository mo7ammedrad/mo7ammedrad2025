<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Handle booking status update
if (isset($_GET['id']) && isset($_GET['status'])) {
    $booking_id = (int)$_GET['id'];
    $status = cleanInput($_GET['status']);
    
    $allowed_statuses = ['pending', 'confirmed', 'cancelled', 'completed'];
    
    if (in_array($status, $allowed_statuses)) {
        $update_query = "UPDATE bookings SET booking_status = :status WHERE booking_id = :booking_id";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bindParam(':status', $status);
        $update_stmt->bindParam(':booking_id', $booking_id);
        
        if ($update_stmt->execute()) {
            $_SESSION['success_message'] = "Booking status updated successfully!";
        } else {
            $_SESSION['error_message'] = "Error updating booking status.";
        }
    } else {
        $_SESSION['error_message'] = "Invalid booking status.";
    }
    
    // Redirect to avoid resubmission
    redirect(SITE_URL . '/admin/bookings.php');
}

// Handle filters
$status_filter = isset($_GET['status_filter']) ? cleanInput($_GET['status_filter']) : '';
$from_date = isset($_GET['from_date']) ? cleanInput($_GET['from_date']) : '';
$to_date = isset($_GET['to_date']) ? cleanInput($_GET['to_date']) : '';

// Build query based on filters
$params = [];
$query = "
    SELECT b.*, u.username, u.full_name, u.email, h.hotel_name, 
           r.room_number, rt.type_name AS room_type_name
    FROM bookings b
    JOIN users u ON b.user_id = u.user_id
    JOIN rooms r ON b.room_id = r.room_id
    JOIN room_types rt ON r.room_type_id = rt.room_type_id
    JOIN hotels h ON rt.hotel_id = h.hotel_id
    WHERE 1=1
";

if (!empty($status_filter)) {
    $query .= " AND b.booking_status = :status_filter";
    $params[':status_filter'] = $status_filter;
}

if (!empty($from_date)) {
    $query .= " AND b.check_in_date >= :from_date";
    $params[':from_date'] = $from_date;
}

if (!empty($to_date)) {
    $query .= " AND b.check_out_date <= :to_date";
    $params[':to_date'] = $to_date;
}

$query .= " ORDER BY b.booking_date DESC";

$stmt = $conn->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get booking stats
$stats_query = "
    SELECT 
        COUNT(*) as total_bookings,
        SUM(CASE WHEN booking_status = 'confirmed' THEN 1 ELSE 0 END) as confirmed_bookings,
        SUM(CASE WHEN booking_status = 'pending' THEN 1 ELSE 0 END) as pending_bookings,
        SUM(CASE WHEN booking_status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_bookings,
        SUM(CASE WHEN booking_status = 'completed' THEN 1 ELSE 0 END) as completed_bookings
    FROM bookings
";
$stats_stmt = $conn->prepare($stats_query);
$stats_stmt->execute();
$booking_stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manage Bookings</h1>
            </div>
            
            <!-- Booking Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-4">
                    <div class="card dashboard-card h-100 bg-light-info">
                        <div class="card-body">
                            <h6 class="card-title text-muted">Total Bookings</h6>
                            <h2 class="mb-0"><?php echo $booking_stats['total_bookings']; ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card dashboard-card h-100 bg-light-success">
                        <div class="card-body">
                            <h6 class="card-title text-muted">Confirmed</h6>
                            <h2 class="mb-0"><?php echo $booking_stats['confirmed_bookings']; ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card dashboard-card h-100 bg-light-warning">
                        <div class="card-body">
                            <h6 class="card-title text-muted">Pending</h6>
                            <h2 class="mb-0"><?php echo $booking_stats['pending_bookings']; ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card dashboard-card h-100 bg-light-danger">
                        <div class="card-body">
                            <h6 class="card-title text-muted">Cancelled</h6>
                            <h2 class="mb-0"><?php echo $booking_stats['cancelled_bookings']; ?></h2>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Booking Filters -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-filter me-1"></i>
                    Filter Bookings
                </div>
                <div class="card-body">
                    <form action="bookings.php" method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label for="status_filter" class="form-label">Booking Status</label>
                            <select class="form-select" id="status_filter" name="status_filter">
                                <option value="" <?php echo $status_filter === '' ? 'selected' : ''; ?>>All Statuses</option>
                                <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="confirmed" <?php echo $status_filter === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                <option value="completed" <?php echo $status_filter === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="cancelled" <?php echo $status_filter === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="from_date" class="form-label">From Date</label>
                            <input type="date" class="form-control" id="from_date" name="from_date" value="<?php echo $from_date; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="to_date" class="form-label">To Date</label>
                            <input type="date" class="form-control" id="to_date" name="to_date" value="<?php echo $to_date; ?>">
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">Apply Filters</button>
                            <a href="bookings.php" class="btn btn-secondary">Reset</a>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Bookings List -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-calendar-check me-1"></i>
                    All Bookings
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="bookingsTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Customer</th>
                                    <th>Hotel & Room</th>
                                    <th>Check-in / Check-out</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Booked On</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($bookings as $booking): ?>
                                    <tr>
                                        <td><?php echo $booking['booking_id']; ?></td>
                                        <td>
                                            <?php echo $booking['full_name']; ?><br>
                                            <small class="text-muted"><?php echo $booking['email']; ?></small>
                                        </td>
                                        <td>
                                            <strong><?php echo $booking['hotel_name']; ?></strong><br>
                                            <small class="text-muted">Room <?php echo $booking['room_number']; ?> (<?php echo $booking['room_type_name']; ?>)</small>
                                        </td>
                                        <td>
                                            <?php echo date('M d, Y', strtotime($booking['check_in_date'])); ?><br>
                                            <small class="text-muted"><?php echo date('M d, Y', strtotime($booking['check_out_date'])); ?></small>
                                        </td>
                                        <td>$<?php echo number_format($booking['total_price'], 2); ?></td>
                                        <td>
                                            <?php 
                                            $status_class = 'secondary';
                                            if ($booking['booking_status'] === 'confirmed') {
                                                $status_class = 'success';
                                            } elseif ($booking['booking_status'] === 'cancelled') {
                                                $status_class = 'danger';
                                            } elseif ($booking['booking_status'] === 'pending') {
                                                $status_class = 'warning';
                                            } elseif ($booking['booking_status'] === 'completed') {
                                                $status_class = 'info';
                                            }
                                            ?>
                                            <span class="badge bg-<?php echo $status_class; ?>">
                                                <?php echo ucfirst($booking['booking_status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($booking['booking_date'])); ?></td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                                    Actions
                                                </button>
                                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                                    <li>
                                                        <a class="dropdown-item" href="booking_details.php?id=<?php echo $booking['booking_id']; ?>">
                                                            <i class="fas fa-eye me-1"></i> View Details
                                                        </a>
                                                    </li>
                                                    <?php if ($booking['booking_status'] === 'pending'): ?>
                                                    <li>
                                                        <a class="dropdown-item" href="bookings.php?id=<?php echo $booking['booking_id']; ?>&status=confirmed">
                                                            <i class="fas fa-check me-1"></i> Confirm
                                                        </a>
                                                    </li>
                                                    <?php endif; ?>
                                                    <?php if ($booking['booking_status'] === 'confirmed'): ?>
                                                    <li>
                                                        <a class="dropdown-item" href="bookings.php?id=<?php echo $booking['booking_id']; ?>&status=completed">
                                                            <i class="fas fa-flag-checkered me-1"></i> Mark as Completed
                                                        </a>
                                                    </li>
                                                    <?php endif; ?>
                                                    <?php if ($booking['booking_status'] !== 'cancelled' && $booking['booking_status'] !== 'completed'): ?>
                                                    <li>
                                                        <a class="dropdown-item" href="bookings.php?id=<?php echo $booking['booking_id']; ?>&status=cancelled">
                                                            <i class="fas fa-times me-1"></i> Cancel
                                                        </a>
                                                    </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($bookings)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No bookings found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#bookingsTable').DataTable();
});
</script>

<?php include '../includes/footer.php'; ?>
