<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Get report type from GET parameter, default to 'booking'
$report_type = isset($_GET['type']) ? cleanInput($_GET['type']) : 'booking';
$valid_types = ['booking', 'revenue', 'occupancy', 'user'];

if (!in_array($report_type, $valid_types)) {
    $report_type = 'booking';
}

// Get date range from GET parameters
$from_date = isset($_GET['from_date']) ? cleanInput($_GET['from_date']) : date('Y-m-d', strtotime('-30 days'));
$to_date = isset($_GET['to_date']) ? cleanInput($_GET['to_date']) : date('Y-m-d');

// Generate report data based on type
$report_data = [];
$chart_labels = [];
$chart_values = [];

switch ($report_type) {
    case 'booking':
        // Get bookings per day in the selected date range
        $query = "
            SELECT DATE(booking_date) as date, COUNT(*) as count
            FROM bookings
            WHERE booking_date BETWEEN :from_date AND :to_date
            GROUP BY DATE(booking_date)
            ORDER BY date
        ";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':from_date', $from_date);
        $stmt->bindParam(':to_date', $to_date);
        $stmt->execute();
        $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format data for chart
        foreach ($report_data as $row) {
            $chart_labels[] = date('M d', strtotime($row['date']));
            $chart_values[] = $row['count'];
        }
        break;
        
    case 'revenue':
        // Get revenue per day in the selected date range
        $query = "
            SELECT DATE(booking_date) as date, SUM(total_price) as revenue
            FROM bookings
            WHERE booking_date BETWEEN :from_date AND :to_date
            AND booking_status IN ('confirmed', 'completed')
            GROUP BY DATE(booking_date)
            ORDER BY date
        ";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':from_date', $from_date);
        $stmt->bindParam(':to_date', $to_date);
        $stmt->execute();
        $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format data for chart
        foreach ($report_data as $row) {
            $chart_labels[] = date('M d', strtotime($row['date']));
            $chart_values[] = $row['revenue'];
        }
        break;
        
    case 'occupancy':
        // Get hotel occupancy rate
        $query = "
            SELECT h.hotel_name,
                   COUNT(DISTINCT r.room_id) as total_rooms,
                   COUNT(DISTINCT CASE 
                       WHEN b.booking_status IN ('confirmed', 'pending') 
                            AND CURDATE() BETWEEN b.check_in_date AND b.check_out_date
                       THEN r.room_id 
                       ELSE NULL 
                   END) as occupied_rooms
            FROM hotels h
            JOIN room_types rt ON h.hotel_id = rt.hotel_id
            JOIN rooms r ON rt.room_type_id = r.room_type_id
            LEFT JOIN bookings b ON r.room_id = b.room_id
            GROUP BY h.hotel_id
            ORDER BY h.hotel_name
        ";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format data for chart
        foreach ($report_data as $row) {
            $occupancy_rate = $row['total_rooms'] > 0 ? ($row['occupied_rooms'] / $row['total_rooms']) * 100 : 0;
            $chart_labels[] = $row['hotel_name'];
            $chart_values[] = round($occupancy_rate, 2);
        }
        break;
        
    case 'user':
        // Get new user registrations per day
        $query = "
            SELECT DATE(created_at) as date, COUNT(*) as count
            FROM users
            WHERE created_at BETWEEN :from_date AND :to_date
            GROUP BY DATE(created_at)
            ORDER BY date
        ";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':from_date', $from_date);
        $stmt->bindParam(':to_date', $to_date);
        $stmt->execute();
        $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format data for chart
        foreach ($report_data as $row) {
            $chart_labels[] = date('M d', strtotime($row['date']));
            $chart_values[] = $row['count'];
        }
        break;
}

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="room_types.php">
                            <i class="fas fa-door-open me-2"></i> Room Types
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Reports & Analytics</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.print();">
                        <i class="fas fa-print me-1"></i> Print Report
                    </button>
                </div>
            </div>
            
            <!-- Report Type Selection -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-filter me-1"></i>
                    Report Options
                </div>
                <div class="card-body">
                    <form action="reports.php" method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label for="type" class="form-label">Report Type</label>
                            <select class="form-select" id="type" name="type" onchange="this.form.submit()">
                                <option value="booking" <?php echo $report_type === 'booking' ? 'selected' : ''; ?>>Booking Statistics</option>
                                <option value="revenue" <?php echo $report_type === 'revenue' ? 'selected' : ''; ?>>Revenue Report</option>
                                <option value="occupancy" <?php echo $report_type === 'occupancy' ? 'selected' : ''; ?>>Hotel Occupancy</option>
                                <option value="user" <?php echo $report_type === 'user' ? 'selected' : ''; ?>>User Registrations</option>
                            </select>
                        </div>
                        
                        <?php if ($report_type !== 'occupancy'): ?>
                        <div class="col-md-3">
                            <label for="from_date" class="form-label">From Date</label>
                            <input type="date" class="form-control" id="from_date" name="from_date" value="<?php echo $from_date; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="to_date" class="form-label">To Date</label>
                            <input type="date" class="form-control" id="to_date" name="to_date" value="<?php echo $to_date; ?>">
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary">Generate</button>
                        </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            
            <!-- Report Display -->
            <div class="card mb-4">
                <div class="card-header">
                    <?php 
                    $report_title = '';
                    switch ($report_type) {
                        case 'booking':
                            $report_title = 'Booking Statistics';
                            break;
                        case 'revenue':
                            $report_title = 'Revenue Report';
                            break;
                        case 'occupancy':
                            $report_title = 'Hotel Occupancy Rate';
                            break;
                        case 'user':
                            $report_title = 'User Registration Statistics';
                            break;
                    }
                    ?>
                    <i class="fas fa-chart-bar me-1"></i>
                    <?php echo $report_title; ?>
                    <?php if ($report_type !== 'occupancy'): ?>
                        <span class="text-muted ms-2">
                            (<?php echo date('M d, Y', strtotime($from_date)); ?> - <?php echo date('M d, Y', strtotime($to_date)); ?>)
                        </span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="chart-container" style="height: 400px;">
                        <canvas id="reportChart"></canvas>
                    </div>
                    
                    <div class="table-responsive mt-4">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <?php if ($report_type === 'occupancy'): ?>
                                        <th>Hotel</th>
                                        <th>Total Rooms</th>
                                        <th>Occupied Rooms</th>
                                        <th>Occupancy Rate</th>
                                    <?php elseif ($report_type === 'revenue'): ?>
                                        <th>Date</th>
                                        <th>Revenue</th>
                                    <?php else: ?>
                                        <th>Date</th>
                                        <th><?php echo $report_type === 'booking' ? 'Bookings' : 'New Users'; ?></th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($report_type === 'occupancy'): ?>
                                    <?php foreach ($report_data as $row): ?>
                                        <tr>
                                            <td><?php echo $row['hotel_name']; ?></td>
                                            <td><?php echo $row['total_rooms']; ?></td>
                                            <td><?php echo $row['occupied_rooms']; ?></td>
                                            <td>
                                                <?php 
                                                $occupancy_rate = $row['total_rooms'] > 0 ? ($row['occupied_rooms'] / $row['total_rooms']) * 100 : 0;
                                                echo round($occupancy_rate, 2) . '%';
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php elseif ($report_type === 'revenue'): ?>
                                    <?php foreach ($report_data as $row): ?>
                                        <tr>
                                            <td><?php echo date('M d, Y', strtotime($row['date'])); ?></td>
                                            <td>$<?php echo number_format($row['revenue'], 2); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <?php foreach ($report_data as $row): ?>
                                        <tr>
                                            <td><?php echo date('M d, Y', strtotime($row['date'])); ?></td>
                                            <td><?php echo $row['count']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                                
                                <?php if (empty($report_data)): ?>
                                    <tr>
                                        <td colspan="<?php echo $report_type === 'occupancy' ? '4' : '2'; ?>" class="text-center">
                                            No data available for the selected period.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js Script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Report Chart
    const ctx = document.getElementById('reportChart').getContext('2d');
    
    const chartLabels = <?php echo json_encode($chart_labels); ?>;
    const chartValues = <?php echo json_encode($chart_values); ?>;
    const reportType = '<?php echo $report_type; ?>';
    
    let chartConfig = {
        type: reportType === 'occupancy' ? 'bar' : 'line',
        data: {
            labels: chartLabels,
            datasets: [{
                label: '<?php 
                    switch ($report_type) {
                        case 'booking':
                            echo 'Bookings';
                            break;
                        case 'revenue':
                            echo 'Revenue ($)';
                            break;
                        case 'occupancy':
                            echo 'Occupancy Rate (%)';
                            break;
                        case 'user':
                            echo 'New Users';
                            break;
                    }
                ?>',
                data: chartValues,
                backgroundColor: reportType === 'occupancy' ? 'rgba(54, 162, 235, 0.6)' : 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2,
                tension: 0.1
            }]
        },
        options: {
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            if (reportType === 'revenue') {
                                return '$' + value;
                            }
                            if (reportType === 'occupancy') {
                                return value + '%';
                            }
                            return value;
                        }
                    }
                }
            }
        }
    };
    
    const reportChart = new Chart(ctx, chartConfig);
</script>

<?php include '../includes/footer.php'; ?>
