<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Initialize variables
$hotel_id = isset($_GET['hotel_id']) ? (int)$_GET['hotel_id'] : 0;
$type_name = "";
$price = "";
$capacity = 2;
$description = "";
$image_path = "";
$max_occupancy = 0;
$errors = [];

// Get all hotels for the dropdown
$hotels_query = "SELECT hotel_id, hotel_name FROM hotels ORDER BY hotel_name";
$hotels_stmt = $conn->prepare($hotels_query);
$hotels_stmt->execute();
$hotels = $hotels_stmt->fetchAll(PDO::FETCH_ASSOC);

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize inputs
    $hotel_id = isset($_POST['hotel_id']) ? (int)$_POST['hotel_id'] : 0;
    $type_name = cleanInput($_POST['type_name']);
    $price = isset($_POST['price']) ? (float)$_POST['price'] : 0;
    $capacity = isset($_POST['capacity']) ? (int)$_POST['capacity'] : 1;
    $description = cleanInput($_POST['description']);
    $max_occupancy = isset($_POST['max_occupancy']) ? (int)$_POST['max_occupancy'] : 0;
    
    // Check for required fields
    if ($hotel_id <= 0) {
        $errors[] = "Hotel is required";
    }
    if (empty($type_name)) {
        $errors[] = "Room type name is required";
    }
    if ($price <= 0) {
        $errors[] = "Price must be greater than 0";
    }
    if ($capacity <= 0) {
        $errors[] = "Capacity must be at least 1";
    }
    if ($max_occupancy <= 0) {
        $errors[] = "Max occupancy must be at least 1";
    }
    
    // Check if room type already exists for this hotel
    if (empty($errors)) {
        $check_query = "SELECT COUNT(*) FROM room_types WHERE hotel_id = :hotel_id AND type_name = :type_name";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->bindParam(':hotel_id', $hotel_id);
        $check_stmt->bindParam(':type_name', $type_name);
        $check_stmt->execute();
        
        if ($check_stmt->fetchColumn() > 0) {
            $errors[] = "Room type name already exists for this hotel";
        }
    }
    
    // Handle image upload
    if (isset($_FILES['room_type_image']) && $_FILES['room_type_image']['error'] == 0) {
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        $file_name = $_FILES['room_type_image']['name'];
        $file_size = $_FILES['room_type_image']['size'];
        $file_tmp = $_FILES['room_type_image']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Check file extension
        if (!in_array($file_ext, $allowed_ext)) {
            $errors[] = "Extension not allowed: " . $file_ext . " - Please upload images only (jpg, jpeg, png, gif)";
        }
        
        // Check file size (5MB max)
        if ($file_size > 5000000) {
            $errors[] = "File size must be less than 5MB";
        }
        
        // If no errors, move the uploaded file
        if (empty($errors)) {
            $new_file_name = uniqid() . "." . $file_ext;
            $upload_path = "../assets/img/rooms/" . $new_file_name;
            $image_path = "assets/img/rooms/" . $new_file_name;
            
            // Create directory if it doesn't exist
            if (!file_exists("../assets/img/rooms/")) {
                mkdir("../assets/img/rooms/", 0777, true);
            }
            
            // Move the file
            if (move_uploaded_file($file_tmp, $upload_path)) {
                // File uploaded successfully
            } else {
                $errors[] = "Error uploading file";
                $image_path = "";
            }
        }
    }
    
    // If no errors, insert the room type into the database
    if (empty($errors)) {
        try {
            $query = "INSERT INTO room_types (hotel_id, type_name, price, capacity, description, image_path, max_occupancy) VALUES (:hotel_id, :type_name, :price, :capacity, :description, :image_path, :max_occupancy)";
            $stmt = $conn->prepare($query);
            
            $stmt->bindParam(':hotel_id', $hotel_id);
            $stmt->bindParam(':type_name', $type_name);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':capacity', $capacity);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':image_path', $image_path);
            $stmt->bindParam(':max_occupancy', $max_occupancy);
            
            if ($stmt->execute()) {
                $_SESSION['success_message'] = "Room type added successfully!";
                redirect(SITE_URL . '/admin/room_types.php?hotel_id=' . $hotel_id);
            } else {
                $errors[] = "Error adding room type";
            }
        } catch (Exception $e) {
            $errors[] = "Error: " . $e->getMessage();
        }
    }
}

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="rooms.php">
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Add New Room Type</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="<?php echo $hotel_id > 0 ? 'room_types.php?hotel_id=' . $hotel_id : 'room_types.php'; ?>" class="btn btn-sm btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Back to Room Types
                    </a>
                </div>
            </div>
            
            <!-- Display Errors -->
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <!-- Add Room Type Form -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-bed me-1"></i>
                    Room Type Information
                </div>
                <div class="card-body">
                    <?php if (count($hotels) == 0): ?>
                        <div class="alert alert-warning">
                            No hotels available. Please <a href="hotel_add.php">add a hotel</a> first.
                        </div>
                    <?php else: ?>
                        <form action="<?php echo $_SERVER['PHP_SELF'] . ($hotel_id > 0 ? '?hotel_id=' . $hotel_id : ''); ?>" method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="hotel_id" class="form-label">Hotel <span class="text-danger">*</span></label>
                                <select class="form-select" id="hotel_id" name="hotel_id" required>
                                    <option value="">Select Hotel</option>
                                    <?php foreach ($hotels as $hotel): ?>
                                        <option value="<?php echo $hotel['hotel_id']; ?>" <?php echo $hotel_id == $hotel['hotel_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($hotel['hotel_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="type_name" class="form-label">Room Type Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="type_name" name="type_name" value="<?php echo htmlspecialchars($type_name); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="price" class="form-label">Price per Night ($) <span class="text-danger">*</span></label>
                                <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?php echo $price; ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="capacity" class="form-label">Capacity <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="capacity" name="capacity" min="1" max="10" value="<?php echo $capacity; ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($description); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="room_type_image" class="form-label">Room Image</label>
                                <input type="file" class="form-control" id="room_type_image" name="room_type_image">
                                <div class="form-text">Upload an image for the room type. Recommended size: 800x600 pixels.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="max_occupancy" class="form-label">Max Occupancy <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="max_occupancy" name="max_occupancy" min="1" value="<?php echo $max_occupancy; ?>" required>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="reset" class="btn btn-outline-secondary me-md-2">Reset</button>
                                <button type="submit" class="btn btn-primary">Add Room Type</button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
