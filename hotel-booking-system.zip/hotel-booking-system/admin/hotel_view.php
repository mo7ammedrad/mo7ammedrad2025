
<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in and is an admin
checkLoginRedirect();
checkAdminRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Initialize variables
$hotel_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Check if hotel_id is valid
if ($hotel_id <= 0) {
    $_SESSION['error_message'] = "Invalid hotel ID";
    redirect(SITE_URL . '/admin/hotels.php');
}

// Get hotel data
$query = "
    SELECT h.*, 
           AVG(r.rating) as average_rating,
           COUNT(DISTINCT r.review_id) as review_count
    FROM hotels h
    LEFT JOIN reviews r ON h.hotel_id = r.hotel_id
    WHERE h.hotel_id = :hotel_id
    GROUP BY h.hotel_id
";
$stmt = $conn->prepare($query);
$stmt->bindParam(':hotel_id', $hotel_id);
$stmt->execute();

$hotel = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$hotel) {
    $_SESSION['error_message'] = "Hotel not found";
    redirect(SITE_URL . '/admin/hotels.php');
}

// Get room types for this hotel
$room_types_query = "SELECT * FROM room_types WHERE hotel_id = :hotel_id";
$room_types_stmt = $conn->prepare($room_types_query);
$room_types_stmt->bindParam(':hotel_id', $hotel_id);
$room_types_stmt->execute();
$room_types = $room_types_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get room count by type
$rooms_by_type = [];
foreach ($room_types as $type) {
    $count_query = "SELECT COUNT(*) FROM rooms WHERE room_type_id = :room_type_id";
    $count_stmt = $conn->prepare($count_query);
    $count_stmt->bindParam(':room_type_id', $type['room_type_id']);
    $count_stmt->execute();
    $rooms_by_type[$type['room_type_id']] = $count_stmt->fetchColumn();
}

// Get latest reviews
$reviews_query = "
    SELECT r.*, u.username, u.full_name
    FROM reviews r
    JOIN users u ON r.user_id = u.user_id
    WHERE r.hotel_id = :hotel_id
    ORDER BY r.review_date DESC
    LIMIT 5
";
$reviews_stmt = $conn->prepare($reviews_query);
$reviews_stmt->bindParam(':hotel_id', $hotel_id);
$reviews_stmt->execute();
$reviews = $reviews_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get booking stats
$booking_stats_query = "
    SELECT COUNT(*) as total_bookings,
           SUM(CASE WHEN b.booking_status = 'confirmed' OR b.booking_status = 'completed' THEN 1 ELSE 0 END) as confirmed_bookings
    FROM bookings b
    JOIN rooms r ON b.room_id = r.room_id
    JOIN room_types rt ON r.room_type_id = rt.room_type_id
    WHERE rt.hotel_id = :hotel_id
";
$booking_stats_stmt = $conn->prepare($booking_stats_query);
$booking_stats_stmt->bindParam(':hotel_id', $hotel_id);
$booking_stats_stmt->execute();
$booking_stats = $booking_stats_stmt->fetch(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="hotels.php">
                            <i class="fas fa-hotel me-2"></i> Hotels
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rooms.php">
                            <i class="fas fa-bed me-2"></i> Rooms
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bookings.php">
                            <i class="fas fa-calendar-check me-2"></i> Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">
                            <i class="fas fa-star me-2"></i> Reviews
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><?php echo htmlspecialchars($hotel['hotel_name']); ?></h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="hotel_edit.php?id=<?php echo $hotel_id; ?>" class="btn btn-sm btn-primary me-2">
                        <i class="fas fa-edit me-1"></i> Edit Hotel
                    </a>
                    <a href="rooms.php?hotel_id=<?php echo $hotel_id; ?>" class="btn btn-sm btn-success me-2">
                        <i class="fas fa-bed me-1"></i> Manage Rooms
                    </a>
                    <a href="hotels.php" class="btn btn-sm btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Back to Hotels
                    </a>
                </div>
            </div>
            
            <!-- Hotel Details -->
            <div class="row mb-4">
                <!-- Hotel Image -->
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body text-center">
                            <img src="<?php echo !empty($hotel['image_path']) ? '../' . $hotel['image_path'] : '../assets/img/hotel-placeholder.jpg'; ?>" 
                                 class="img-fluid rounded" alt="<?php echo htmlspecialchars($hotel['hotel_name']); ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Hotel Information -->
                <div class="col-md-8">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-info-circle me-1"></i>
                            Hotel Information
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-3 fw-bold">Hotel Name:</div>
                                <div class="col-md-9"><?php echo htmlspecialchars($hotel['hotel_name']); ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-3 fw-bold">Location:</div>
                                <div class="col-md-9"><?php echo htmlspecialchars($hotel['location']); ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-3 fw-bold">Rating:</div>
                                <div class="col-md-9">
                                    <?php 
                                    $rating = round($hotel['average_rating'], 1);
                                    if ($rating > 0) {
                                        echo $rating . ' / 5 ';
                                        for ($i = 1; $i <= 5; $i++) {
                                            if ($i <= $rating) {
                                                echo '<i class="fas fa-star text-warning"></i>';
                                            } elseif ($i - 0.5 <= $rating) {
                                                echo '<i class="fas fa-star-half-alt text-warning"></i>';
                                            } else {
                                                echo '<i class="far fa-star text-warning"></i>';
                                            }
                                        }
                                        echo ' <small>(' . $hotel['review_count'] . ' reviews)</small>';
                                    } else {
                                        echo 'No ratings yet';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-3 fw-bold">Created:</div>
                                <div class="col-md-9"><?php echo formatDate($hotel['created_at']); ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-3 fw-bold">Description:</div>
                                <div class="col-md-9">
                                    <?php if (!empty($hotel['description'])): ?>
                                        <?php echo nl2br(htmlspecialchars($hotel['description'])); ?>
                                    <?php else: ?>
                                        <em>No description available</em>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Statistics -->
            <div class="row mb-4">
                <!-- Room Types -->
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-bed me-1"></i>
                            Room Types
                        </div>
                        <div class="card-body">
                            <?php if (!empty($room_types)): ?>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Type Name</th>
                                                <th>Price</th>
                                                <th>Capacity</th>
                                                <th>Rooms</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($room_types as $type): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($type['room_type_name']); ?></td>
                                                    <td>$<?php echo number_format($type['price'], 2); ?></td>
                                                    <td><?php echo $type['capacity']; ?> persons</td>
                                                    <td><?php echo $rooms_by_type[$type['room_type_id']] ?? 0; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p>No room types defined for this hotel.</p>
                                <a href="room_type_add.php?hotel_id=<?php echo $hotel_id; ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-plus me-1"></i> Add Room Type
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Booking Statistics -->
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-chart-pie me-1"></i>
                            Booking Statistics
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 text-center mb-3">
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $booking_stats['total_bookings'] ?? 0; ?></div>
                                    <div class="small text-gray-500">Total Bookings</div>
                                </div>
                                <div class="col-md-6 text-center mb-3">
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $booking_stats['confirmed_bookings'] ?? 0; ?></div>
                                    <div class="small text-gray-500">Confirmed/Completed</div>
                                </div>
                            </div>
                            <div class="text-center mt-4">
                                <a href="bookings.php?hotel_id=<?php echo $hotel_id; ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-calendar-check me-1"></i> View All Bookings
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Latest Reviews -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-star me-1"></i>
                    Latest Reviews
                </div>
                <div class="card-body">
                    <?php if (!empty($reviews)): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Rating</th>
                                        <th>Comment</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($reviews as $review): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($review['full_name'] ?? $review['username']); ?></td>
                                            <td>
                                                <?php 
                                                for ($i = 1; $i <= 5; $i++) {
                                                    echo $i <= $review['rating'] 
                                                        ? '<i class="fas fa-star text-warning"></i>' 
                                                        : '<i class="far fa-star text-warning"></i>';
                                                }
                                                ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($review['comment']); ?></td>
                                            <td><?php echo formatDate($review['review_date']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p>No reviews for this hotel yet.</p>
                    <?php endif; ?>
                    <div class="text-center mt-3">
                        <a href="reviews.php?hotel_id=<?php echo $hotel_id; ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-eye me-1"></i> View All Reviews
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
