
<?php
// Include the configuration file
require_once 'config/config.php';

// Check if hotel ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "Hotel ID is missing.";
    redirect(SITE_URL . '/hotels.php');
}

$hotel_id = (int)$_GET['id'];

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Get hotel details
$query = "
    SELECT h.*, 
           AVG(r.rating) as average_rating,
           COUNT(DISTINCT r.review_id) as review_count
    FROM hotels h
    LEFT JOIN reviews r ON h.hotel_id = r.hotel_id
    WHERE h.hotel_id = :hotel_id
    GROUP BY h.hotel_id";

$stmt = $conn->prepare($query);
$stmt->bindParam(':hotel_id', $hotel_id);
$stmt->execute();

if ($stmt->rowCount() === 0) {
    $_SESSION['error_message'] = "Hotel not found.";
    redirect(SITE_URL . '/hotels.php');
}

$hotel = $stmt->fetch(PDO::FETCH_ASSOC);

// Get hotel amenities
$amenities_query = "
    SELECT a.amenity_name
    FROM amenities a
    JOIN hotel_amenities ha ON a.amenity_id = ha.amenity_id
    WHERE ha.hotel_id = :hotel_id
    ORDER BY a.amenity_name";

$amenities_stmt = $conn->prepare($amenities_query);
$amenities_stmt->bindParam(':hotel_id', $hotel_id);
$amenities_stmt->execute();
$amenities = $amenities_stmt->fetchAll(PDO::FETCH_COLUMN);

// Get room types for this hotel
$rooms_query = "
    SELECT rt.*, 
           (SELECT COUNT(*) FROM rooms r 
            WHERE r.room_type_id = rt.room_type_id 
            AND r.status = 'available') as available_rooms
    FROM room_types rt
    WHERE rt.hotel_id = :hotel_id
    ORDER BY rt.price ASC";

$rooms_stmt = $conn->prepare($rooms_query);
$rooms_stmt->bindParam(':hotel_id', $hotel_id);
$rooms_stmt->execute();
$room_types = $rooms_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get check-in and check-out dates from URL if available
$check_in = isset($_GET['check_in_date']) && !empty($_GET['check_in_date']) ? $_GET['check_in_date'] : '';
$check_out = isset($_GET['check_out_date']) && !empty($_GET['check_out_date']) ? $_GET['check_out_date'] : '';

// Get reviews for this hotel
$reviews_query = "
    SELECT r.*, u.username, u.full_name 
    FROM reviews r
    JOIN users u ON r.user_id = u.user_id
    WHERE r.hotel_id = :hotel_id
    ORDER BY r.review_date DESC
    LIMIT 5";

$reviews_stmt = $conn->prepare($reviews_query);
$reviews_stmt->bindParam(':hotel_id', $hotel_id);
$reviews_stmt->execute();
$reviews = $reviews_stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="container py-5">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo SITE_URL; ?>/index.php">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo SITE_URL; ?>/hotels.php">Hotels</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $hotel['hotel_name']; ?></li>
        </ol>
    </nav>
    
    <div class="row">
        <!-- Hotel Details -->
        <div class="col-md-8">
            <h1><?php echo $hotel['hotel_name']; ?></h1>
            
            <div class="mb-3">
                <p class="text-muted">
                    <i class="fas fa-map-marker-alt me-1"></i> <?php echo $hotel['location']; ?>
                </p>
                
                <div class="mb-2">
                    <?php 
                    $rating = round($hotel['average_rating'], 1);
                    for ($i = 1; $i <= 5; $i++) {
                        if ($i <= $rating) {
                            echo '<i class="fas fa-star rating-stars"></i>';
                        } else if ($i - 0.5 <= $rating) {
                            echo '<i class="fas fa-star-half-alt rating-stars"></i>';
                        } else {
                            echo '<i class="far fa-star rating-stars"></i>';
                        }
                    }
                    echo " <strong>" . number_format($rating, 1) . "</strong>";
                    ?>
                    <span class="text-muted ms-1">(<?php echo $hotel['review_count']; ?> reviews)</span>
                </div>
            </div>
            
            <div class="mb-4">
                <img src="<?php echo !empty($hotel['image_path']) ? $hotel['image_path'] : 'assets/img/hotel-placeholder.jpg'; ?>" 
                     class="img-fluid rounded" alt="<?php echo $hotel['hotel_name']; ?>">
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Description</h5>
                </div>
                <div class="card-body">
                    <p class="card-text"><?php echo nl2br($hotel['description']); ?></p>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Amenities</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php if (count($amenities) > 0): ?>
                            <?php foreach ($amenities as $amenity): ?>
                                <div class="col-md-4 mb-2">
                                    <i class="fas fa-check-circle text-success me-2"></i> <?php echo $amenity; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="col-12">
                                <p class="text-muted">No amenities listed for this hotel.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Guest Reviews</h5>
                </div>
                <div class="card-body">
                    <?php if (count($reviews) > 0): ?>
                        <?php foreach ($reviews as $review): ?>
                            <div class="mb-4 pb-3 border-bottom">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6><?php echo $review['full_name']; ?></h6>
                                        <div>
                                            <?php 
                                            for ($i = 1; $i <= 5; $i++) {
                                                if ($i <= $review['rating']) {
                                                    echo '<i class="fas fa-star rating-stars"></i>';
                                                } else {
                                                    echo '<i class="far fa-star rating-stars"></i>';
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="text-muted">
                                        <small><?php echo date('M d, Y', strtotime($review['review_date'])); ?></small>
                                    </div>
                                </div>
                                <p class="mt-2"><?php echo nl2br($review['comment']); ?></p>
                            </div>
                        <?php endforeach; ?>
                        <?php if ($hotel['review_count'] > 5): ?>
                            <div class="text-center">
                                <a href="#" class="btn btn-outline-primary">View All <?php echo $hotel['review_count']; ?> Reviews</a>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="text-muted">No reviews yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Sidebar with Room Types -->
        <div class="col-md-4">
            <div class="card mb-4 sticky-top" style="top: 20px;">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Available Rooms</h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($check_in) && !empty($check_out)): ?>
                        <div class="alert alert-info mb-3">
                            <p class="mb-1">
                                <strong>Check-in:</strong> <?php echo formatDate($check_in); ?>
                            </p>
                            <p class="mb-0">
                                <strong>Check-out:</strong> <?php echo formatDate($check_out); ?>
                            </p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (count($room_types) > 0): ?>
                        <div class="accordion" id="roomTypesAccordion">
                            <?php foreach ($room_types as $index => $room): ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading<?php echo $index; ?>">
                                        <button class="accordion-button <?php echo $index > 0 ? 'collapsed' : ''; ?>" 
                                                type="button" data-bs-toggle="collapse" 
                                                data-bs-target="#collapse<?php echo $index; ?>" 
                                                aria-expanded="<?php echo $index === 0 ? 'true' : 'false'; ?>" 
                                                aria-controls="collapse<?php echo $index; ?>">
                                            <div class="w-100 d-flex justify-content-between">
                                                <span><?php echo $room['type_name']; ?></span>
                                                <span class="text-primary"><?php echo '$' . number_format($room['price'], 2); ?>/night</span>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo $index; ?>" 
                                         class="accordion-collapse collapse <?php echo $index === 0 ? 'show' : ''; ?>" 
                                         aria-labelledby="heading<?php echo $index; ?>" 
                                         data-bs-parent="#roomTypesAccordion">
                                        <div class="accordion-body">
                                            <?php if (!empty($room['image_path'])): ?>
                                                <img src="<?php echo $room['image_path']; ?>" class="img-fluid mb-2 rounded" alt="<?php echo $room['type_name']; ?>">
                                            <?php endif; ?>
                                            
                                            <p><strong>Capacity:</strong> <?php echo $room['capacity']; ?> guests</p>
                                            <p><?php echo $room['description']; ?></p>
                                            
                                            <?php if ($room['available_rooms'] > 0): ?>
                                                <div class="d-grid mt-2">
                                                    <a href="booking.php?room_type=<?php echo $room['room_type_id']; ?>&check_in=<?php echo $check_in; ?>&check_out=<?php echo $check_out; ?>" 
                                                       class="btn btn-success">
                                                       Book Now - <?php echo $room['available_rooms']; ?> rooms available
                                                    </a>
                                                </div>
                                            <?php else: ?>
                                                <div class="alert alert-warning mb-0">
                                                    No rooms available for this type
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            No room information available for this hotel.
                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-footer">
                    <form action="hotel_details.php" method="GET">
                        <input type="hidden" name="id" value="<?php echo $hotel_id; ?>">
                        <div class="row g-2">
                            <div class="col-md-6 mb-2">
                                <label for="check_in_date" class="form-label small">Check-in</label>
                                <input type="date" class="form-control datepicker" id="check_in_date" name="check_in_date" 
                                       value="<?php echo htmlspecialchars($check_in); ?>">
                            </div>
                            <div class="col-md-6 mb-2">
                                <label for="check_out_date" class="form-label small">Check-out</label>
                                <input type="date" class="form-control datepicker" id="check_out_date" name="check_out_date" 
                                       value="<?php echo htmlspecialchars($check_out); ?>">
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary w-100">Check Availability</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
