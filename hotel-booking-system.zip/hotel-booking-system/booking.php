
<?php
// Include the configuration file
require_once 'config/config.php';

// Check if the user is logged in
checkLoginRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Check if required parameters are provided
if (!isset($_GET['room_type_id']) || empty($_GET['room_type_id']) ||
    !isset($_GET['check_in']) || empty($_GET['check_in']) ||
    !isset($_GET['check_out']) || empty($_GET['check_out'])) {
    $_SESSION['error_message'] = "Missing required booking information.";
    redirect(SITE_URL);
}

$room_type_id = (int)$_GET['room_type_id'];
$check_in_date = date('Y-m-d', strtotime($_GET['check_in']));
$check_out_date = date('Y-m-d', strtotime($_GET['check_out']));
$guests = isset($_GET['guests']) ? (int)$_GET['guests'] : 1;

// Validate dates
if ($check_in_date < date('Y-m-d') || $check_out_date <= $check_in_date) {
    $_SESSION['error_message'] = "Invalid booking dates. Check-in must be today or later, and check-out must be after check-in.";
    redirect(SITE_URL);
}

// Get room type details
$room_query = "
    SELECT rt.*, h.hotel_name, h.location, h.image_path as hotel_image
    FROM room_types rt
    JOIN hotels h ON rt.hotel_id = h.hotel_id
    WHERE rt.room_type_id = :room_type_id";
    
$room_stmt = $conn->prepare($room_query);
$room_stmt->bindParam(':room_type_id', $room_type_id);
$room_stmt->execute();

// Check if room type exists
if ($room_stmt->rowCount() === 0) {
    $_SESSION['error_message'] = "Room type not found.";
    redirect(SITE_URL);
}

$room_type = $room_stmt->fetch(PDO::FETCH_ASSOC);

// Check if guest count exceeds max occupancy
if ($guests > $room_type['max_occupancy']) {
    $_SESSION['error_message'] = "The selected room type can accommodate up to {$room_type['max_occupancy']} guests.";
    redirect("hotel.php?id={$room_type['hotel_id']}");
}

// Find available rooms of the selected type
$available_rooms_query = "
    SELECT r.* 
    FROM rooms r
    WHERE r.room_type_id = :room_type_id
    AND r.room_id NOT IN (
        SELECT b.room_id FROM bookings b 
        WHERE b.booking_status != 'cancelled' 
        AND ((b.check_in_date <= :check_out_date AND b.check_out_date >= :check_in_date) 
        OR (b.check_in_date IS NULL))
    )
    LIMIT 1";

$available_rooms_stmt = $conn->prepare($available_rooms_query);
$available_rooms_stmt->bindParam(':room_type_id', $room_type_id);
$available_rooms_stmt->bindParam(':check_in_date', $check_in_date);
$available_rooms_stmt->bindParam(':check_out_date', $check_out_date);
$available_rooms_stmt->execute();

// Check if any rooms are available
if ($available_rooms_stmt->rowCount() === 0) {
    $_SESSION['error_message'] = "Sorry, there are no available rooms of this type for the selected dates.";
    redirect("hotel.php?id={$room_type['hotel_id']}");
}

$available_room = $available_rooms_stmt->fetch(PDO::FETCH_ASSOC);

// Calculate booking details
$check_in = new DateTime($check_in_date);
$check_out = new DateTime($check_out_date);
$nights = $check_in->diff($check_out)->days;
$total_price = $room_type['price'] * $nights;

// Get user information
$user_query = "SELECT * FROM users WHERE user_id = :user_id";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bindParam(':user_id', $_SESSION['user_id']);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

// Process booking form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_booking'])) {
    // Retrieve form data
    $special_requests = isset($_POST['special_requests']) ? cleanInput($_POST['special_requests']) : '';
    $payment_method = isset($_POST['payment_method']) ? cleanInput($_POST['payment_method']) : 'credit_card';
    
    // Insert booking
    $booking_query = "
        INSERT INTO bookings (user_id, room_id, check_in_date, check_out_date, num_guests, 
                             total_price, booking_date, special_requests, booking_status)
        VALUES (:user_id, :room_id, :check_in_date, :check_out_date, :num_guests, 
               :total_price, NOW(), :special_requests, 'confirmed')";
    
    $booking_stmt = $conn->prepare($booking_query);
    $booking_stmt->bindParam(':user_id', $_SESSION['user_id']);
    $booking_stmt->bindParam(':room_id', $available_room['room_id']);
    $booking_stmt->bindParam(':check_in_date', $check_in_date);
    $booking_stmt->bindParam(':check_out_date', $check_out_date);
    $booking_stmt->bindParam(':num_guests', $guests);
    $booking_stmt->bindParam(':total_price', $total_price);
    $booking_stmt->bindParam(':special_requests', $special_requests);
    
    if ($booking_stmt->execute()) {
        $booking_id = $conn->lastInsertId();
        $_SESSION['success_message'] = "Your booking has been confirmed successfully!";
        
        // In a real application, you would process payment here and send
        // confirmation emails to the user and hotel management
        
        redirect("booking_confirmation.php?id=$booking_id");
    } else {
        $_SESSION['error_message'] = "Error processing your booking. Please try again.";
    }
}

// Include header
include 'includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <div class="col-md-8">
            <h1 class="mb-4">Book Your Stay</h1>
            
            <!-- Booking Form -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-calendar-plus me-2"></i> Booking Details
                    </h5>
                </div>
                <div class="card-body">
                    <form action="booking.php?room_type_id=<?php echo $room_type_id; ?>&check_in=<?php echo $check_in_date; ?>&check_out=<?php echo $check_out_date; ?>&guests=<?php echo $guests; ?>" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Guest Information</label>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <input type="text" class="form-control" value="<?php echo $user['full_name']; ?>" readonly>
                                    <small class="text-muted">Full Name</small>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <input type="email" class="form-control" value="<?php echo $user['email']; ?>" readonly>
                                    <small class="text-muted">Email Address</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="special_requests" class="form-label">Special Requests (optional)</label>
                            <textarea class="form-control" id="special_requests" name="special_requests" rows="3" placeholder="Any special requests for your stay..."></textarea>
                            <small class="text-muted">We'll do our best to accommodate your requests, but they cannot be guaranteed.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Payment Method</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_method" id="credit_card" value="credit_card" checked>
                                <label class="form-check-label" for="credit_card">
                                    <i class="fab fa-cc-visa me-2"></i>
                                    <i class="fab fa-cc-mastercard me-2"></i>
                                    <i class="fab fa-cc-amex me-2"></i>
                                    Credit Card
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_method" id="paypal" value="paypal">
                                <label class="form-check-label" for="paypal">
                                    <i class="fab fa-paypal me-2"></i>
                                    PayPal
                                </label>
                            </div>
                            <small class="text-muted d-block mt-1">Note: This is a demo application. No actual payment will be processed.</small>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="terms" name="terms" required>
                            <label class="form-check-label" for="terms">
                                I agree to the <a href="terms.php" target="_blank">terms and conditions</a> and <a href="cancellation_policy.php" target="_blank">cancellation policy</a>
                            </label>
                        </div>
                        
                        <div class="d-grid">
                            <button type="submit" name="confirm_booking" class="btn btn-primary">
                                <i class="fas fa-check-circle me-2"></i> Complete Booking
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <!-- Booking Summary -->
            <div class="card mb-4 sticky-top" style="top: 20px; z-index: 100;">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-receipt me-2"></i> Booking Summary
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center mb-4">
                        <img src="<?php echo !empty($room_type['hotel_image']) ? $room_type['hotel_image'] : 'assets/img/hotel-placeholder.jpg'; ?>" 
                             class="rounded me-3" alt="<?php echo $room_type['hotel_name']; ?>" style="width: 64px; height: 64px; object-fit: cover;">
                        <div>
                            <h5 class="mb-0"><?php echo $room_type['hotel_name']; ?></h5>
                            <p class="mb-0 text-muted"><small><?php echo $room_type['location']; ?></small></p>
                        </div>
                    </div>
                    
                    <h6 class="border-bottom pb-2 mb-3"><?php echo $room_type['type_name']; ?></h6>
                    
                    <div class="d-flex justify-content-between mb-2">
                        <span>Check-in:</span>
                        <span class="fw-bold"><?php echo date('D, M j, Y', strtotime($check_in_date)); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Check-out:</span>
                        <span class="fw-bold"><?php echo date('D, M j, Y', strtotime($check_out_date)); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Stay Duration:</span>
                        <span><?php echo $nights; ?> night<?php echo $nights > 1 ? 's' : ''; ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Guests:</span>
                        <span><?php echo $guests; ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Price per night:</span>
                        <span>$<?php echo number_format($room_type['price'], 2); ?></span>
                    </div>
                    
                    <hr>
                    
                    <div class="d-flex justify-content-between align-items-center fs-5">
                        <span class="fw-bold">Total Price:</span>
                        <span class="fw-bold">$<?php echo number_format($total_price, 2); ?></span>
                    </div>
                    <small class="text-muted d-block text-end">Includes taxes and fees</small>
                </div>
                <div class="card-footer bg-light">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-shield-alt text-success me-2"></i>
                        <small>Secure booking process with instant confirmation</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
