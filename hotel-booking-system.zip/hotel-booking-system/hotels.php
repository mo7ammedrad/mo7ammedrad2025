<?php
// Include the configuration file
require_once 'config/config.php';

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Get filters from GET parameters
$location_filter = isset($_GET['location']) ? cleanInput($_GET['location']) : '';
$price_min = isset($_GET['price_min']) ? (int)$_GET['price_min'] : 0;
$price_max = isset($_GET['price_max']) ? (int)$_GET['price_max'] : 1000;
$rating_filter = isset($_GET['rating']) ? (int)$_GET['rating'] : 0;

// Build the query based on filters
$query = "
    SELECT h.*, 
           MIN(rt.price) as min_price,
           MAX(rt.price) as max_price,
           AVG(r.rating) as average_rating,
           COUNT(r.review_id) as review_count
    FROM hotels h
    LEFT JOIN room_types rt ON h.hotel_id = rt.hotel_id
    LEFT JOIN reviews r ON h.hotel_id = r.hotel_id
    WHERE 1=1";

$params = array();

// Add location filter if provided
if (!empty($location_filter)) {
    $query .= " AND (h.location LIKE :location OR h.hotel_name LIKE :location)";
    $location_param = "%{$location_filter}%";
    $params[':location'] = $location_param;
}

// Add price filter
$query .= " AND rt.price BETWEEN :price_min AND :price_max";
$params[':price_min'] = $price_min;
$params[':price_max'] = $price_max;

$query .= " GROUP BY h.hotel_id";

// Add rating filter if provided
if ($rating_filter > 0) {
    $query .= " HAVING average_rating >= :rating";
    $params[':rating'] = $rating_filter;
}

// Add sorting
$sort = isset($_GET['sort']) ? cleanInput($_GET['sort']) : 'rating';
if ($sort === 'price_low') {
    $query .= " ORDER BY min_price ASC";
} elseif ($sort === 'price_high') {
    $query .= " ORDER BY max_price DESC";
} else {
    // Default sort by rating
    $query .= " ORDER BY average_rating DESC";
}

$stmt = $conn->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$hotels = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
require_once 'includes/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Find Your Perfect Hotel</h1>
    
    <!-- Filters Section -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="hotels.php" method="GET">
                <div class="row g-3">
                    <div class="col-lg-4 col-md-6">
                        <label for="location" class="form-label">Location</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                            <input type="text" class="form-control" id="location" name="location" 
                                   value="<?php echo $location_filter; ?>" placeholder="City, hotel name...">
                        </div>
                    </div>
                    
                    <div class="col-lg-2 col-md-3">
                        <label for="price_min" class="form-label">Min Price ($)</label>
                        <input type="number" class="form-control" id="price_min" name="price_min" 
                               value="<?php echo $price_min; ?>" min="0" max="10000">
                    </div>
                    
                    <div class="col-lg-2 col-md-3">
                        <label for="price_max" class="form-label">Max Price ($)</label>
                        <input type="number" class="form-control" id="price_max" name="price_max" 
                               value="<?php echo $price_max; ?>" min="0" max="10000">
                    </div>
                    
                    <div class="col-lg-2 col-md-6">
                        <label for="rating" class="form-label">Min Rating</label>
                        <select class="form-select" id="rating" name="rating">
                            <option value="0" <?php if ($rating_filter == 0) echo 'selected'; ?>>Any Rating</option>
                            <option value="3" <?php if ($rating_filter == 3) echo 'selected'; ?>>3+ Stars</option>
                            <option value="4" <?php if ($rating_filter == 4) echo 'selected'; ?>>4+ Stars</option>
                            <option value="4.5" <?php if ($rating_filter == 4.5) echo 'selected'; ?>>4.5+ Stars</option>
                        </select>
                    </div>
                    
                    <div class="col-lg-2 col-md-6">
                        <label for="sort" class="form-label">Sort By</label>
                        <select class="form-select" id="sort" name="sort">
                            <option value="rating" <?php if ($sort == 'rating') echo 'selected'; ?>>Top Rated</option>
                            <option value="price_low" <?php if ($sort == 'price_low') echo 'selected'; ?>>Price: Low to High</option>
                            <option value="price_high" <?php if ($sort == 'price_high') echo 'selected'; ?>>Price: High to Low</option>
                        </select>
                    </div>
                    
                    <div class="col-12 text-center mt-4">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search me-2"></i> Search Hotels
                        </button>
                        <a href="hotels.php" class="btn btn-outline-secondary ms-2">
                            <i class="fas fa-times me-2"></i> Clear Filters
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Results Count -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <p class="mb-0"><?php echo count($hotels); ?> hotels found</p>
    </div>
    
    <!-- Hotels List -->
    <?php if (count($hotels) > 0): ?>
        <div class="row g-4">
            <?php foreach ($hotels as $hotel): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 shadow-sm hotel-card">
                        <img src="<?php echo !empty($hotel['image_path']) ? $hotel['image_path'] : 'assets/img/hotel-placeholder.jpg'; ?>" 
                             class="card-img-top" alt="<?php echo $hotel['hotel_name']; ?>" style="height: 200px; object-fit: cover;">
                        
                        <?php if (isset($hotel['discount']) && $hotel['discount'] > 0): ?>
                            <div class="badge bg-danger position-absolute top-0 end-0 m-2">
                                <?php echo $hotel['discount']; ?>% OFF
                            </div>
                        <?php endif; ?>
                        
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $hotel['hotel_name']; ?></h5>
                            
                            <div class="d-flex align-items-center mb-2">
                                <span class="me-2"><i class="fas fa-map-marker-alt text-muted"></i></span>
                                <span class="text-muted small"><?php echo $hotel['location']; ?></span>
                            </div>
                            
                            <div class="d-flex align-items-center mb-3">
                                <?php
                                $avg_rating = isset($hotel['average_rating']) ? $hotel['average_rating'] : 0;
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= floor($avg_rating)) {
                                        echo '<i class="fas fa-star text-warning me-1"></i>';
                                    } elseif ($i - 0.5 <= $avg_rating) {
                                        echo '<i class="fas fa-star-half-alt text-warning me-1"></i>';
                                    } else {
                                        echo '<i class="far fa-star text-warning me-1"></i>';
                                    }
                                }
                                ?>
                                <span class="ms-1">
                                    <?php echo number_format($avg_rating, 1); ?>
                                    <small class="text-muted">(<?php echo $hotel['review_count']; ?>)</small>
                                </span>
                            </div>
                            
                            <p class="card-text small text-truncate mb-3"><?php echo $hotel['description']; ?></p>
                            
                            <?php if (!empty($hotel['amenities'])): ?>
                                <div class="mb-3">
                                    <div class="d-flex flex-wrap gap-2">
                                        <?php 
                                        $amenities = explode(',', $hotel['amenities']); 
                                        $display_amenities = array_slice($amenities, 0, 3);
                                        foreach ($display_amenities as $amenity): 
                                        ?>
                                            <span class="badge bg-light text-dark"><?php echo trim($amenity); ?></span>
                                        <?php endforeach; ?>
                                        <?php if (count($amenities) > 3): ?>
                                            <span class="badge bg-light text-dark">+<?php echo count($amenities) - 3; ?> more</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center mt-auto">
                                <div>
                                    <span class="text-muted small">From</span>
                                    <div class="fw-bold">$<?php echo number_format($hotel['min_price'], 2); ?>/night</div>
                                </div>
                                <a href="hotel.php?id=<?php echo $hotel['hotel_id']; ?>" class="btn btn-primary">
                                    View Details
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center p-5">
            <i class="fas fa-info-circle fa-3x mb-3"></i>
            <h4>No hotels found matching your criteria</h4>
            <p>Try adjusting your filters or search for a different location.</p>
            <a href="hotels.php" class="btn btn-primary mt-2">View All Hotels</a>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
