
<?php
// Include the configuration file
require_once 'config/config.php';

// Check if the user is logged in
checkLoginRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Check if booking ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid booking ID.";
    redirect(SITE_URL);
}

$booking_id = (int)$_GET['id'];

// Get booking details
$query = "
    SELECT b.*, r.room_number, rt.type_name, rt.price,
           h.hotel_name, h.location, h.image_path as hotel_image
    FROM bookings b
    JOIN rooms r ON b.room_id = r.room_id
    JOIN room_types rt ON r.room_type_id = rt.room_type_id
    JOIN hotels h ON rt.hotel_id = h.hotel_id
    WHERE b.booking_id = :booking_id AND b.user_id = :user_id";
    
$stmt = $conn->prepare($query);
$stmt->bindParam(':booking_id', $booking_id);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();

// Check if booking exists and belongs to the user
if ($stmt->rowCount() === 0) {
    $_SESSION['error_message'] = "Booking not found or you don't have permission to view it.";
    redirect(SITE_URL);
}

$booking = $stmt->fetch(PDO::FETCH_ASSOC);

// Calculate booking details
$check_in = new DateTime($booking['check_in_date']);
$check_out = new DateTime($booking['check_out_date']);
$nights = $check_in->diff($check_out)->days;

// Include header
include 'includes/header.php';
?>

<div class="container py-5">
    <div class="text-center mb-5">
        <div class="d-inline-flex justify-content-center align-items-center rounded-circle bg-success text-white p-3 mb-3" style="width: 70px; height: 70px;">
            <i class="fas fa-check-circle fa-3x"></i>
        </div>
        <h1 class="mb-2">Booking Confirmed!</h1>
        <p class="lead">Thank you for your booking. Your reservation is now confirmed.</p>
    </div>
    
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <!-- Booking Details Card -->
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Booking Reference: #<?php echo str_pad($booking['booking_id'], 6, '0', STR_PAD_LEFT); ?></h5>
                        <span class="badge bg-success">Confirmed</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-4 mb-3 mb-md-0">
                            <img src="<?php echo !empty($booking['hotel_image']) ? $booking['hotel_image'] : 'assets/img/hotel-placeholder.jpg'; ?>" 
                                 class="img-fluid rounded" alt="<?php echo $booking['hotel_name']; ?>">
                        </div>
                        <div class="col-md-8">
                            <h4><?php echo $booking['hotel_name']; ?></h4>
                            <p class="text-muted"><i class="fas fa-map-marker-alt me-2"></i> <?php echo $booking['location']; ?></p>
                            
                            <h5 class="mt-3"><?php echo $booking['type_name']; ?> (Room #<?php echo $booking['room_number']; ?>)</h5>
                            <p class="mb-0"><i class="fas fa-users me-2"></i> <?php echo $booking['num_guests']; ?> Guest<?php echo $booking['num_guests'] > 1 ? 's' : ''; ?></p>
                        </div>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-md-4 mb-3 mb-md-0">
                            <div class="card bg-light">
                                <div class="card-body text-center p-3">
                                    <h6 class="text-muted mb-1">Check-in</h6>
                                    <h5 class="mb-0"><?php echo date('D, M j, Y', strtotime($booking['check_in_date'])); ?></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3 mb-md-0">
                            <div class="card bg-light">
                                <div class="card-body text-center p-3">
                                    <h6 class="text-muted mb-1">Check-out</h6>
                                    <h5 class="mb-0"><?php echo date('D, M j, Y', strtotime($booking['check_out_date'])); ?></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-light">
                                <div class="card-body text-center p-3">
                                    <h6 class="text-muted mb-1">Stay Duration</h6>
                                    <h5 class="mb-0"><?php echo $nights; ?> Night<?php echo $nights > 1 ? 's' : ''; ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-responsive mb-4">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th class="text-end">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo $booking['type_name']; ?> x <?php echo $nights; ?> night<?php echo $nights > 1 ? 's' : ''; ?></td>
                                    <td class="text-end">$<?php echo number_format($booking['total_price'], 2); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="border-0"></td>
                                </tr>
                                <tr class="fw-bold">
                                    <td>Total</td>
                                    <td class="text-end">$<?php echo number_format($booking['total_price'], 2); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <?php if (!empty($booking['special_requests'])): ?>
                        <div class="mb-4">
                            <h6>Special Requests:</h6>
                            <p class="mb-0"><?php echo nl2br(htmlspecialchars($booking['special_requests'])); ?></p>
                        </div>
                    <?php endif; ?>
                    
                    <div class="alert alert-info mb-0">
                        <h6 class="alert-heading"><i class="fas fa-info-circle me-2"></i> Important Information</h6>
                        <p class="mb-0">
                            Please present your booking reference number at check-in. For any changes to your booking,
                            please contact the hotel directly or visit your account dashboard.
                        </p>
                    </div>
                </div>
                <div class="card-footer bg-light">
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center">
                        <div class="mb-3 mb-md-0">
                            <small class="text-muted">A confirmation email has been sent to your registered email address.</small>
                        </div>
                        <div>
                            <button onclick="window.print();" class="btn btn-outline-secondary me-2">
                                <i class="fas fa-print me-2"></i> Print
                            </button>
                            <a href="user/booking_detail.php?id=<?php echo $booking_id; ?>" class="btn btn-primary">
                                <i class="fas fa-eye me-2"></i> View Details
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Next Steps -->
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="mb-0">What's Next?</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 mb-4 mb-md-0 text-center">
                            <div class="d-flex justify-content-center">
                                <div class="rounded-circle bg-light d-flex justify-content-center align-items-center mb-3" style="width: 60px; height: 60px;">
                                    <i class="fas fa-calendar-check fa-2x text-primary"></i>
                                </div>
                            </div>
                            <h5>Booking Managed</h5>
                            <p class="text-muted small">View and manage your booking in your account dashboard</p>
                            <a href="user/bookings.php" class="btn btn-sm btn-outline-primary">My Bookings</a>
                        </div>
                        <div class="col-md-4 mb-4 mb-md-0 text-center">
                            <div class="d-flex justify-content-center">
                                <div class="rounded-circle bg-light d-flex justify-content-center align-items-center mb-3" style="width: 60px; height: 60px;">
                                    <i class="fas fa-hotel fa-2x text-primary"></i>
                                </div>
                            </div>
                            <h5>Explore Hotel</h5>
                            <p class="text-muted small">Learn more about the hotel, facilities and surrounding area</p>
                            <a href="hotel.php?id=<?php echo $booking['hotel_id']; ?>" class="btn btn-sm btn-outline-primary">View Hotel</a>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="d-flex justify-content-center">
                                <div class="rounded-circle bg-light d-flex justify-content-center align-items-center mb-3" style="width: 60px; height: 60px;">
                                    <i class="fas fa-search fa-2x text-primary"></i>
                                </div>
                            </div>
                            <h5>Explore More</h5>
                            <p class="text-muted small">Discover more hotels and destinations for your future stays</p>
                            <a href="index.php" class="btn btn-sm btn-outline-primary">Browse Hotels</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
