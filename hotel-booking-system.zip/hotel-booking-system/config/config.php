<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Site URL configuration
define('SITE_URL', 'http://localhost/hotel-booking-system');

// Include database configuration
require_once 'database.php';

// Helper Functions
function redirect($url) {
    header("Location: {$url}");
    exit;
}

function cleanInput($data) {
    $data = isset($data) ? trim($data) : "";
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function formatDate($date) {
    return date('F j, Y', strtotime($date));
}

function formatDateTime($date) {
    return date('F j, Y, g:i a', strtotime($date));
}

function formatCurrency($amount) {
    return '$' . number_format($amount, 2);
}

function checkLoginRedirect() {
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['error_message'] = "Please log in to access this page.";
        redirect(SITE_URL . '/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    }
}

function checkAdminRedirect() {
    if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
        $_SESSION['error_message'] = "You don't have permission to access this page.";
        redirect(SITE_URL);
    }
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

// Handle "Remember Me" functionality
function checkRememberMe() {
    if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_user']) && isset($_COOKIE['remember_token'])) {
        $user_id = $_COOKIE['remember_user'];
        $token = $_COOKIE['remember_token'];
        
        $database = new Database();
        $conn = $database->getConnection();
        
        $query = "
            SELECT u.* FROM users u
            JOIN remember_tokens rt ON u.user_id = rt.user_id
            WHERE rt.user_id = :user_id 
            AND rt.token = :token
            AND rt.expires_at > NOW()";
            
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':token', $token);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Set user session
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_type'] = $user['user_type'];
            
            if ($user['user_type'] === 'admin') {
                $_SESSION['is_admin'] = true;
            }
            
            // Update token expiry
            $expires = date('Y-m-d H:i:s', time() + 30 * 24 * 60 * 60); // 30 days
            
            $update_query = "UPDATE remember_tokens SET expires_at = :expires_at WHERE user_id = :user_id AND token = :token";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bindParam(':expires_at', $expires);
            $update_stmt->bindParam(':user_id', $user_id);
            $update_stmt->bindParam(':token', $token);
            $update_stmt->execute();
            
            // Refresh cookies
            setcookie('remember_user', $user_id, time() + 30 * 24 * 60 * 60, '/', '', false, true);
            setcookie('remember_token', $token, time() + 30 * 24 * 60 * 60, '/', '', false, true);
        }
    }
}

// Call remember me check
checkRememberMe();
