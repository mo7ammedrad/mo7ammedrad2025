
<?php
// Include the configuration file
require_once 'config/config.php';

// Unset all of the session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Set success message for next session
session_start();
$_SESSION['success_message'] = "You have been successfully logged out!";

// Redirect to the login page
redirect(SITE_URL . '/index.php');
?>
