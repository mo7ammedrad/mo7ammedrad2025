
// Custom JavaScript for Hotel Booking System

// Document Ready Function
document.addEventListener('DOMContentLoaded', function() {
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            // Create Bootstrap alert instance and hide it
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Initialize date pickers if they exist
    const dateInputs = document.querySelectorAll('.datepicker');
    if (dateInputs.length > 0) {
        dateInputs.forEach(function(input) {
            // Set min date as today
            const today = new Date().toISOString().split('T')[0];
            input.setAttribute('min', today);
        });
    }

    // Calculate total price on booking form
    const calculatePrice = function() {
        const checkInDate = document.getElementById('check_in_date');
        const checkOutDate = document.getElementById('check_out_date');
        const roomPrice = document.getElementById('room_price');
        const totalPriceElement = document.getElementById('total_price');
        const totalPriceInput = document.getElementById('total_price_input');
        
        if (checkInDate && checkOutDate && roomPrice && totalPriceElement && totalPriceInput) {
            checkInDate.addEventListener('change', updateTotal);
            checkOutDate.addEventListener('change', updateTotal);
            
            function updateTotal() {
                if (checkInDate.value && checkOutDate.value) {
                    const start = new Date(checkInDate.value);
                    const end = new Date(checkOutDate.value);
                    
                    // Validate dates
                    if (end <= start) {
                        alert('Check-out date must be after check-in date');
                        checkOutDate.value = '';
                        return;
                    }
                    
                    // Calculate days (add 1 because the last day counts too)
                    const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
                    const pricePerNight = parseFloat(roomPrice.dataset.price);
                    const total = days * pricePerNight;
                    
                    // Update displayed total and hidden input
                    totalPriceElement.textContent = total.toFixed(2);
                    totalPriceInput.value = total.toFixed(2);
                }
            }
        }
    };
    
    calculatePrice();

    // Rating star selection for reviews
    const ratingStars = document.querySelectorAll('.rating-star');
    if (ratingStars.length > 0) {
        const ratingInput = document.getElementById('rating');
        
        ratingStars.forEach(function(star) {
            star.addEventListener('click', function() {
                const value = this.dataset.value;
                ratingInput.value = value;
                
                // Update visual state of stars
                ratingStars.forEach(function(s) {
                    if (s.dataset.value <= value) {
                        s.classList.add('text-warning');
                        s.classList.replace('far', 'fas');
                    } else {
                        s.classList.remove('text-warning');
                        s.classList.replace('fas', 'far');
                    }
                });
            });
        });
    }

    // Confirm delete actions
    const deleteButtons = document.querySelectorAll('.delete-btn');
    if (deleteButtons.length > 0) {
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', function(e) {
                if (!confirm('Are you sure you want to delete this item?')) {
                    e.preventDefault();
                }
            });
        });
    }
});

// Function to validate search form
function validateSearchForm() {
    const locationInput = document.getElementById('location');
    const checkInDate = document.getElementById('check_in_date');
    const checkOutDate = document.getElementById('check_out_date');
    
    if (!locationInput.value.trim()) {
        alert('Please enter a destination');
        locationInput.focus();
        return false;
    }
    
    if (!checkInDate.value) {
        alert('Please select a check-in date');
        checkInDate.focus();
        return false;
    }
    
    if (!checkOutDate.value) {
        alert('Please select a check-out date');
        checkOutDate.focus();
        return false;
    }
    
    return true;
}

// Function to preview image before upload
function previewImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('imagePreview').src = e.target.result;
            document.getElementById('imagePreview').style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
