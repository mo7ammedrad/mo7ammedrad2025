</main>
    
    <!-- Footer -->
    <footer class="footer py-5 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4 mb-lg-0">
                    <h5 class="text-white mb-3">Hotel<span class="text-warning">Haven</span></h5>
                    <p class="mb-3">Your premier platform for online hotel reservations. Find the perfect stay for your next adventure.</p>
                    <p class="small">
                        &copy; <?php echo date('Y'); ?> HotelHaven<br>
                        Course 1393 Project<br>
                        Al-Quds Open University
                    </p>
                </div>
                
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <h6 class="text-white mb-3">Quick Links</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="<?php echo SITE_URL; ?>/index.php">Home</a></li>
                        <li class="mb-2"><a href="<?php echo SITE_URL; ?>/hotels.php">Hotels</a></li>
                        <li class="mb-2"><a href="<?php echo SITE_URL; ?>/about.php">About Us</a></li>
                        <li class="mb-2"><a href="<?php echo SITE_URL; ?>/contact.php">Contact</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                    <h6 class="text-white mb-3">Legal</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="<?php echo SITE_URL; ?>/terms.php">Terms & Conditions</a></li>
                        <li class="mb-2"><a href="<?php echo SITE_URL; ?>/privacy.php">Privacy Policy</a></li>
                        <li class="mb-2"><a href="<?php echo SITE_URL; ?>/faq.php">FAQ</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-4 col-md-4">
                    <h6 class="text-white mb-3">Contact Us</h6>
                    <address class="mb-0 text-secondary">
                        <p><i class="fas fa-map-marker-alt me-2"></i> Al-Quds Open University, Palestine</p>
                        <p><i class="fas fa-envelope me-2"></i> info@hotelhaven.com</p>
                        <p><i class="fas fa-phone me-2"></i> +970 123 456 789</p>
                    </address>
                    
                    <h6 class="text-white mb-3 mt-4">Follow Us</h6>
                    <div class="d-flex gap-3">
                        <a href="#" class="text-white fs-5"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-white fs-5"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white fs-5"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white fs-5"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Get current page URL
        var currentLocation = window.location.pathname;
        var navLinks = document.querySelectorAll('.navbar-nav .nav-link');
        
        // Add active class to current page nav link
        navLinks.forEach(function(link) {
            if (link.getAttribute('href') === currentLocation.split('/').pop()) {
                link.classList.add('active');
            }
        });
    </script>
</body>
</html>
