<?php
// Include the configuration file
require_once 'config/config.php';

// Include header
require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row mb-5">
        <div class="col-lg-8 mx-auto text-center">
            <h1 class="display-4 fw-bold">About HotelHaven</h1>
            <p class="lead text-muted">Your trusted partner for finding the perfect accommodation worldwide</p>
        </div>
    </div>
    
    <div class="row mb-5">
        <div class="col-md-6 mb-4 mb-md-0">
            <img src="assets/img/about-image.jpg" alt="Hotel lobby" class="img-fluid rounded shadow-lg">
        </div>
        <div class="col-md-6">
            <h2>Our Story</h2>
            <p>HotelHaven was founded in 2023 with a simple mission: to make booking accommodations as seamless and enjoyable as the stay itself. What started as a small project for a university course has evolved into a comprehensive platform serving travelers worldwide.</p>
            <p>Our team of dedicated professionals shares a passion for travel and technology, constantly striving to improve the booking experience for our users. We understand that finding the right place to stay is a crucial part of any journey, and we take pride in facilitating this process.</p>
            <p>At HotelHaven, we believe that everyone deserves a comfortable, convenient, and memorable stay, regardless of their budget or destination. This belief drives everything we do, from our user-friendly interface to our extensive range of accommodations and competitive pricing.</p>
        </div>
    </div>
    
    <div class="row mb-5">
        <div class="col-lg-8 mx-auto text-center">
            <h2>Our Mission</h2>
            <p class="lead">To provide travelers with a seamless, transparent, and reliable platform to find and book their ideal accommodations, while supporting our hotel partners in reaching their target audience.</p>
        </div>
    </div>
    
    <div class="row mb-5">
        <div class="col-md-4 mb-4 mb-md-0">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body text-center p-4">
                    <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center mx-auto mb-4" style="width: 80px; height: 80px;">
                        <i class="fas fa-users fa-3x text-white"></i>
                    </div>
                    <h3>Our Team</h3>
                    <p>HotelHaven is powered by a diverse team of travel enthusiasts, technology experts, and customer service specialists. Our collaborative approach ensures that we deliver a product that meets the needs of both travelers and hoteliers.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4 mb-md-0">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body text-center p-4">
                    <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center mx-auto mb-4" style="width: 80px; height: 80px;">
                        <i class="fas fa-handshake fa-3x text-white"></i>
                    </div>
                    <h3>Our Partners</h3>
                    <p>We work with thousands of hotels, from boutique establishments to international chains, to provide our users with a comprehensive selection of accommodations. Our partnerships are built on mutual trust, transparency, and shared success.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body text-center p-4">
                    <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center mx-auto mb-4" style="width: 80px; height: 80px;">
                        <i class="fas fa-globe fa-3x text-white"></i>
                    </div>
                    <h3>Our Reach</h3>
                    <p>HotelHaven currently serves travelers from over 50 countries, offering accommodations in more than 100 destinations worldwide. We're continuously expanding our reach to provide our services to even more regions around the globe.</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card border-0 shadow">
                <div class="card-body p-5">
                    <h2 class="text-center mb-4">Why Choose HotelHaven?</h2>
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="me-3">
                                    <i class="fas fa-check-circle text-primary fa-2x"></i>
                                </div>
                                <div>
                                    <h4>Best Price Guarantee</h4>
                                    <p>We offer competitive rates with no hidden fees, ensuring you get the best value for your money.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="me-3">
                                    <i class="fas fa-check-circle text-primary fa-2x"></i>
                                </div>
                                <div>
                                    <h4>Wide Selection</h4>
                                    <p>From luxury resorts to budget-friendly options, we have accommodations to suit every preference and budget.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4 mb-md-0">
                            <div class="d-flex">
                                <div class="me-3">
                                    <i class="fas fa-check-circle text-primary fa-2x"></i>
                                </div>
                                <div>
                                    <h4>Secure Booking</h4>
                                    <p>Our platform uses advanced security measures to ensure your personal and payment information is protected.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex">
                                <div class="me-3">
                                    <i class="fas fa-check-circle text-primary fa-2x"></i>
                                </div>
                                <div>
                                    <h4>24/7 Support</h4>
                                    <p>Our customer service team is available around the clock to assist you with any queries or issues.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
