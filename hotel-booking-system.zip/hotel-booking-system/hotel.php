<?php
// Include the configuration file
require_once 'config/config.php';

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Check if hotel ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid hotel ID.";
    redirect(SITE_URL);
}

$hotel_id = (int)$_GET['id'];

// Get hotel details
$query = "
    SELECT h.*, 
           AVG(r.rating) as average_rating,
           COUNT(r.review_id) as review_count
    FROM hotels h
    LEFT JOIN reviews r ON h.hotel_id = r.hotel_id
    WHERE h.hotel_id = :hotel_id
    GROUP BY h.hotel_id";
    
$stmt = $conn->prepare($query);
$stmt->bindParam(':hotel_id', $hotel_id);
$stmt->execute();

// Check if hotel exists
if ($stmt->rowCount() === 0) {
    $_SESSION['error_message'] = "Hotel not found.";
    redirect(SITE_URL);
}

$hotel = $stmt->fetch(PDO::FETCH_ASSOC);

// Get room types for this hotel
$room_query = "
    SELECT rt.*,
           (SELECT COUNT(*) FROM rooms rm 
            WHERE rm.room_type_id = rt.room_type_id 
            AND rm.room_id NOT IN (
                SELECT b.room_id FROM bookings b 
                WHERE b.booking_status != 'cancelled' 
                AND ((b.check_in_date <= :check_out_date AND b.check_out_date >= :check_in_date) 
                OR (b.check_in_date IS NULL))
            )) as available_rooms
    FROM room_types rt
    WHERE rt.hotel_id = :hotel_id
    ORDER BY rt.price ASC";

// Default date range for availability check (today + 1 day)
$check_in_date = date('Y-m-d');
$check_out_date = date('Y-m-d', strtotime('+1 day'));

// If dates are provided in GET parameters, use them instead
if (isset($_GET['check_in']) && !empty($_GET['check_in']) && 
    isset($_GET['check_out']) && !empty($_GET['check_out'])) {
    $check_in_date = date('Y-m-d', strtotime($_GET['check_in']));
    $check_out_date = date('Y-m-d', strtotime($_GET['check_out']));
}

$room_stmt = $conn->prepare($room_query);
$room_stmt->bindParam(':hotel_id', $hotel_id);
$room_stmt->bindParam(':check_in_date', $check_in_date);
$room_stmt->bindParam(':check_out_date', $check_out_date);
$room_stmt->execute();
$room_types = $room_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get hotel reviews
$reviews_query = "
    SELECT r.*, u.full_name, u.username
    FROM reviews r
    JOIN users u ON r.user_id = u.user_id
    WHERE r.hotel_id = :hotel_id
    ORDER BY r.review_date DESC
    LIMIT 10";
    
$reviews_stmt = $conn->prepare($reviews_query);
$reviews_stmt->bindParam(':hotel_id', $hotel_id);
$reviews_stmt->execute();
$reviews = $reviews_stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
include 'includes/header.php';
?>

<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="mb-2"><?php echo $hotel['hotel_name']; ?></h1>
            <p class="text-muted">
                <i class="fas fa-map-marker-alt me-2"></i> <?php echo $hotel['location']; ?>
                <?php if (!empty($hotel['average_rating'])): ?>
                    <span class="ms-3">
                        <i class="fas fa-star text-warning me-1"></i>
                        <?php echo number_format($hotel['average_rating'], 1); ?>
                        <span class="text-muted">(<?php echo $hotel['review_count']; ?> reviews)</span>
                    </span>
                <?php endif; ?>
            </p>
        </div>
        <div class="col-md-4 text-md-end">
            <a href="index.php" class="btn btn-outline-primary">
                <i class="fas fa-arrow-left me-2"></i> Back to Hotels
            </a>
        </div>
    </div>
    
    <!-- Hotel Images -->
    <div class="card mb-4">
        <div class="row g-0">
            <div class="col-md-8">
                <img src="<?php echo !empty($hotel['image_path']) ? $hotel['image_path'] : 'assets/img/hotel-placeholder.jpg'; ?>" 
                     class="img-fluid rounded-start" alt="<?php echo $hotel['hotel_name']; ?>" style="max-height: 400px; width: 100%; object-fit: cover;">
            </div>
            <div class="col-md-4">
                <div class="card-body">
                    <h5 class="card-title">About this hotel</h5>
                    <p class="card-text"><?php echo $hotel['description']; ?></p>
                    
                    <?php if (!empty($hotel['amenities'])): ?>
                        <h6 class="mt-3">Hotel Amenities:</h6>
                        <ul class="list-unstyled">
                            <?php foreach (explode(',', $hotel['amenities']) as $amenity): ?>
                                <li><i class="fas fa-check text-success me-2"></i> <?php echo trim($amenity); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Room Availability Search Form -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Check Room Availability</h5>
        </div>
        <div class="card-body">
            <form action="hotel.php" method="GET" class="row">
                <input type="hidden" name="id" value="<?php echo $hotel_id; ?>">
                
                <div class="col-md-4 mb-3">
                    <label for="check_in" class="form-label">Check-in Date</label>
                    <input type="date" class="form-control" id="check_in" name="check_in" 
                           value="<?php echo $check_in_date; ?>" min="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <div class="col-md-4 mb-3">
                    <label for="check_out" class="form-label">Check-out Date</label>
                    <input type="date" class="form-control" id="check_out" name="check_out" 
                           value="<?php echo $check_out_date; ?>" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" required>
                </div>
                
                <div class="col-md-2 mb-3">
                    <label for="guests" class="form-label">Guests</label>
                    <select class="form-select" id="guests" name="guests">
                        <?php for ($i = 1; $i <= 10; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php echo (isset($_GET['guests']) && $_GET['guests'] == $i) ? 'selected' : ''; ?>>
                                <?php echo $i; ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                
                <div class="col-md-2 d-flex align-items-end mb-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-2"></i> Check Availability
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Available Room Types -->
    <h2 class="mb-4">Available Rooms</h2>
    
    <?php if (count($room_types) > 0): ?>
        <div class="row row-cols-1 row-cols-md-2 g-4 mb-4">
            <?php foreach ($room_types as $room): ?>
                <div class="col">
                    <div class="card h-100 <?php echo $room['available_rooms'] > 0 ? '' : 'border-danger'; ?>">
                        <?php if ($room['available_rooms'] > 0): ?>
                            <div class="badge bg-success position-absolute top-0 end-0 m-2">
                                <?php echo $room['available_rooms']; ?> room(s) available
                            </div>
                        <?php else: ?>
                            <div class="badge bg-danger position-absolute top-0 end-0 m-2">
                                No rooms available
                            </div>
                        <?php endif; ?>
                        
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="<?php echo !empty($room['image_path']) ? $room['image_path'] : 'assets/img/room-placeholder.jpg'; ?>" 
                                     class="img-fluid rounded-start h-100" alt="<?php echo $room['type_name']; ?>" style="object-fit: cover;">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $room['type_name']; ?></h5>
                                    <p class="card-text"><?php echo $room['description']; ?></p>
                                    
                                    <!-- Room details -->
                                    <div class="row mb-3">
                                        <div class="col-6">
                                            <small class="text-muted d-block">Max Occupancy</small>
                                            <span><i class="fas fa-user me-1"></i> <?php echo isset($room['max_occupancy']) && $room['max_occupancy'] > 0 ? $room['max_occupancy'] : 'N/A'; ?> guest(s)</span>
                                        </div>
                                        <div class="col-6">
                                            <small class="text-muted d-block">Size</small>
                                            <span><?php echo isset($room['size']) ? $room['size'] : 'N/A'; ?> sqm</span>
                                        </div>
                                    </div>
                                    
                                    <?php if (!empty($room['amenities'])): ?>
                                        <div class="mb-3">
                                            <small class="text-muted d-block mb-1">Room Amenities:</small>
                                            <div class="d-flex flex-wrap gap-2">
                                                <?php foreach (explode(',', $room['amenities']) as $amenity): ?>
                                                    <span class="badge bg-light text-dark"><?php echo trim($amenity); ?></span>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="d-flex justify-content-between align-items-center mt-2">
                                        <div>
                                            <small class="text-muted">Price per night</small>
                                            <h5 class="mb-0">$<?php echo number_format($room['price'], 2); ?></h5>
                                        </div>
                                        
                                        <?php if ($room['available_rooms'] > 0 && isset($_SESSION['user_id'])): ?>
                                            <a href="booking.php?room_type_id=<?php echo $room['room_type_id']; ?>&check_in=<?php echo $check_in_date; ?>&check_out=<?php echo $check_out_date; ?>&guests=<?php echo isset($_GET['guests']) ? $_GET['guests'] : '1'; ?>" class="btn btn-primary">
                                                <i class="fas fa-calendar-check me-2"></i> Book Now
                                            </a>
                                        <?php elseif ($room['available_rooms'] > 0): ?>
                                            <a href="login.php?redirect=hotel.php?id=<?php echo $hotel_id; ?>" class="btn btn-outline-primary">
                                                <i class="fas fa-sign-in-alt me-2"></i> Login to Book
                                            </a>
                                        <?php else: ?>
                                            <button class="btn btn-secondary" disabled>
                                                <i class="fas fa-ban me-2"></i> Not Available
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i> No room types available for this hotel.
        </div>
    <?php endif; ?>
    
    <!-- Hotel Reviews -->
    <h2 class="mb-4">Guest Reviews</h2>
    
    <?php if (count($reviews) > 0): ?>
        <div class="row mb-4">
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="card">
                    <div class="card-body text-center">
                        <h1 class="display-4 fw-bold">
                            <?php echo number_format($hotel['average_rating'], 1); ?>
                        </h1>
                        <div class="mb-2">
                            <?php
                            $avg_rating = $hotel['average_rating'];
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= floor($avg_rating)) {
                                    echo '<i class="fas fa-star text-warning"></i>';
                                } elseif ($i - 0.5 <= $avg_rating) {
                                    echo '<i class="fas fa-star-half-alt text-warning"></i>';
                                } else {
                                    echo '<i class="far fa-star text-warning"></i>';
                                }
                            }
                            ?>
                        </div>
                        <p class="text-muted">Based on <?php echo $hotel['review_count']; ?> reviews</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <?php foreach ($reviews as $review): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-2">
                                <div>
                                    <h5 class="card-title mb-0"><?php echo $review['full_name']; ?></h5>
                                    <small class="text-muted">Reviewed on <?php echo formatDate($review['review_date']); ?></small>
                                </div>
                                <div>
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="fas fa-star <?php echo $i <= $review['rating'] ? 'text-warning' : 'text-muted'; ?>"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <p class="card-text"><?php echo nl2br(htmlspecialchars($review['comment'])); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <?php if ($hotel['review_count'] > 10): ?>
                    <div class="text-center mt-3">
                        <a href="reviews.php?hotel_id=<?php echo $hotel_id; ?>" class="btn btn-outline-primary">
                            View All <?php echo $hotel['review_count']; ?> Reviews
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i> No reviews available for this hotel.
        </div>
    <?php endif; ?>
    
    <!-- Hotel Location Map (Placeholder) -->
    <h2 class="mb-4">Location</h2>
    <div class="card mb-4">
        <div class="card-body">
            <p><i class="fas fa-map-marker-alt me-2"></i> <?php echo $hotel['location']; ?></p>
            <!-- In a real app, you would integrate a map API like Google Maps here -->
            <div class="bg-light text-center py-5">
                <p class="mb-0">Map integration would be displayed here</p>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
