<?php
require_once 'config/config.php';

if (isset($_SESSION['user_id'])) {
    redirect(SITE_URL);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = cleanInput($_POST['username']);
    $full_name = cleanInput($_POST['full_name']);
    $email = cleanInput($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $terms = isset($_POST['terms']);
    $errors = [];

    if (empty($username)) $errors[] = "Username is required.";
    if (empty($full_name)) $errors[] = "Full name is required.";
    if (empty($email)) $errors[] = "Email is required.";
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
    if (empty($password)) $errors[] = "Password is required.";
    elseif (strlen($password) < 6) $errors[] = "Password must be at least 6 characters.";
    if ($password !== $confirm_password) $errors[] = "Passwords do not match.";
    if (!$terms) $errors[] = "You must agree to the terms.";

    if (empty($errors)) {
        $db = new Database();
        $conn = $db->getConnection();

        $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username OR email = :email");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount()) {
            $errors[] = "Username or email already exists.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $insert_stmt = $conn->prepare("INSERT INTO users (username, full_name, email, password, user_type, created_at) 
                                           VALUES (:username, :full_name, :email, :password, 'customer', NOW())");
            $insert_stmt->bindParam(':username', $username);
            $insert_stmt->bindParam(':full_name', $full_name);
            $insert_stmt->bindParam(':email', $email);
            $insert_stmt->bindParam(':password', $hashed_password);

            if ($insert_stmt->execute()) {
                $_SESSION['user_id'] = $conn->lastInsertId();
                $_SESSION['username'] = $username;
                $_SESSION['user_type'] = 'user';
                $_SESSION['success_message'] = "Welcome to HotelHaven, $username!";
                redirect(SITE_URL . '/user/dashboard.php');
            } else {
                $errors[] = "Registration failed. Try again.";
            }
        }
    }

    if (!empty($errors)) {
        $_SESSION['error_message'] = implode(' ', $errors);
    }
}

include 'includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-6">
            <div class="card shadow-sm">
                <div class="card-body p-4 p-md-5">
                    <div class="text-center mb-4">
                        <h2 class="fw-bold">Create an Account</h2>
                        <p class="text-muted">Join HotelHaven to start booking your perfect stays</p>
                    </div>
                    
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                                   placeholder="Choose a username" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="full_name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>"
                                   placeholder="Enter your full name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                                   placeholder="Enter your email" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" 
                                   placeholder="Create a password" required>
                            <div class="form-text">Password must be at least 6 characters long</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                   placeholder="Confirm your password" required>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                            <label class="form-check-label" for="terms">
                                I agree to the <a href="terms.php" target="_blank">Terms of Service</a> and <a href="privacy.php" target="_blank">Privacy Policy</a>
                            </label>
                        </div>
                        
                        <div class="d-grid mb-4">
                            <button type="submit" class="btn btn-primary py-2">Create Account</button>
                        </div>
                    </form>                    
                    <div class="text-center">
                        <p class="mb-0">Already have an account? <a href="login.php" class="text-decoration-none fw-bold">Sign in</a></p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-6 d-none d-lg-block">
            <div class="mt-4">
                <h4>Benefits of joining HotelHaven</h4>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item bg-transparent ps-0">
                        <i class="fas fa-check-circle text-primary me-2"></i> Access exclusive member discounts
                    </li>
                    <li class="list-group-item bg-transparent ps-0">
                        <i class="fas fa-check-circle text-primary me-2"></i> Save favorite hotels for future visits
                    </li>
                    <li class="list-group-item bg-transparent ps-0">
                        <i class="fas fa-check-circle text-primary me-2"></i> Faster checkout process
                    </li>
                    <li class="list-group-item bg-transparent ps-0">
                        <i class="fas fa-check-circle text-primary me-2"></i> Manage all your bookings in one place
                    </li>
                    <li class="list-group-item bg-transparent ps-0">
                        <i class="fas fa-check-circle text-primary me-2"></i> Earn rewards points on every booking
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
