
<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in
checkLoginRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Get filter parameters
$status_filter = isset($_GET['status']) ? cleanInput($_GET['status']) : '';
$date_filter = isset($_GET['date_filter']) ? cleanInput($_GET['date_filter']) : '';

// Build the query based on filters
$query = "
    SELECT b.*, r.room_number, rt.type_name, rt.price,
           h.hotel_name, h.location, h.image_path as hotel_image
    FROM bookings b
    JOIN rooms r ON b.room_id = r.room_id
    JOIN room_types rt ON r.room_type_id = rt.room_type_id
    JOIN hotels h ON rt.hotel_id = h.hotel_id
    WHERE b.user_id = :user_id";

// Add status filter if provided
if (!empty($status_filter)) {
    if ($status_filter === 'upcoming') {
        $query .= " AND b.check_in_date >= CURRENT_DATE";
    } elseif ($status_filter === 'ongoing') {
        $query .= " AND b.check_in_date <= CURRENT_DATE AND b.check_out_date >= CURRENT_DATE";
    } elseif ($status_filter === 'completed') {
        $query .= " AND b.check_out_date < CURRENT_DATE";
    } elseif ($status_filter === 'cancelled') {
        $query .= " AND b.booking_status = 'cancelled'";
    } else {
        // If status is explicitly set but not one of the above, use it directly
        $query .= " AND b.booking_status = :status_filter";
    }
}

// Add date filter if provided
if (!empty($date_filter)) {
    if ($date_filter === 'past_month') {
        $query .= " AND b.booking_date >= DATE_SUB(CURRENT_DATE, INTERVAL 1 MONTH)";
    } elseif ($date_filter === 'past_3months') {
        $query .= " AND b.booking_date >= DATE_SUB(CURRENT_DATE, INTERVAL 3 MONTH)";
    } elseif ($date_filter === 'past_year') {
        $query .= " AND b.booking_date >= DATE_SUB(CURRENT_DATE, INTERVAL 1 YEAR)";
    }
}

// Order by booking date (most recent first)
$query .= " ORDER BY b.booking_date DESC";

$stmt = $conn->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);

if (!empty($status_filter) && !in_array($status_filter, ['upcoming', 'ongoing', 'completed', 'cancelled'])) {
    $stmt->bindParam(':status_filter', $status_filter);
}

$stmt->execute();
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user information
$user_query = "SELECT * FROM users WHERE user_id = :user_id";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bindParam(':user_id', $_SESSION['user_id']);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="fas fa-user-circle fa-5x text-secondary"></i>
                    </div>
                    <h5 class="card-title"><?php echo $user['full_name']; ?></h5>
                    <p class="card-text text-muted"><?php echo $user['email']; ?></p>
                </div>
            </div>
            
            <div class="list-group">
                <a href="dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
                <a href="profile.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-user me-2"></i> My Profile
                </a>
                <a href="bookings.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-calendar-check me-2"></i> My Bookings
                </a>
                <a href="reviews.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-star me-2"></i> My Reviews
                </a>
                <a href="../logout.php" class="list-group-item list-group-item-action text-danger">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="mb-0">My Bookings</h1>
            </div>
            
            <!-- Filters -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="get" action="bookings.php">
                        <div class="row">
                            <div class="col-md-4 mb-3 mb-md-0">
                                <label for="status" class="form-label">Status Filter</label>
                                <select id="status" name="status" class="form-select">
                                    <option value="">All Statuses</option>
                                    <option value="upcoming" <?php echo $status_filter == 'upcoming' ? 'selected' : ''; ?>>Upcoming</option>
                                    <option value="ongoing" <?php echo $status_filter == 'ongoing' ? 'selected' : ''; ?>>Ongoing</option>
                                    <option value="completed" <?php echo $status_filter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="cancelled" <?php echo $status_filter == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </div>
                            
                            <div class="col-md-4 mb-3 mb-md-0">
                                <label for="date_filter" class="form-label">Date Filter</label>
                                <select id="date_filter" name="date_filter" class="form-select">
                                    <option value="">All Time</option>
                                    <option value="past_month" <?php echo $date_filter == 'past_month' ? 'selected' : ''; ?>>Past Month</option>
                                    <option value="past_3months" <?php echo $date_filter == 'past_3months' ? 'selected' : ''; ?>>Past 3 Months</option>
                                    <option value="past_year" <?php echo $date_filter == 'past_year' ? 'selected' : ''; ?>>Past Year</option>
                                </select>
                            </div>
                            
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fas fa-filter me-2"></i> Apply Filters
                                </button>
                                <a href="bookings.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-times me-2"></i> Clear
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Bookings List -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-calendar-check me-2"></i> Your Bookings
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (count($bookings) > 0): ?>
                        <?php foreach ($bookings as $booking): ?>
                            <div class="card mb-3 shadow-sm">
                                <div class="row g-0">
                                    <div class="col-md-3">
                                        <img src="<?php echo !empty($booking['hotel_image']) ? '../' . $booking['hotel_image'] : '../assets/img/hotel-placeholder.jpg'; ?>" 
                                             class="img-fluid rounded-start h-100" alt="<?php echo $booking['hotel_name']; ?>" style="object-fit: cover;">
                                    </div>
                                    <div class="col-md-9">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <h5 class="card-title"><?php echo $booking['hotel_name']; ?></h5>
                                                <div>
                                                    <?php
                                                    $status_class = 'bg-secondary';
                                                    if ($booking['booking_status'] === 'confirmed') $status_class = 'bg-success';
                                                    if ($booking['booking_status'] === 'pending') $status_class = 'bg-warning';
                                                    if ($booking['booking_status'] === 'cancelled') $status_class = 'bg-danger';
                                                    ?>
                                                    <span class="badge <?php echo $status_class; ?>">
                                                        <?php echo ucfirst($booking['booking_status']); ?>
                                                    </span>
                                                </div>
                                            </div>
                                            
                                            <p class="card-text text-muted small mb-2"><?php echo $booking['location']; ?></p>
                                            
                                            <div class="row mb-2">
                                                <div class="col-md-6">
                                                    <div class="text-muted small">Check-in</div>
                                                    <div class="fw-bold"><?php echo formatDate($booking['check_in_date']); ?></div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="text-muted small">Check-out</div>
                                                    <div class="fw-bold"><?php echo formatDate($booking['check_out_date']); ?></div>
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-2">
                                                <div class="col-md-6">
                                                    <div class="text-muted small">Room Type</div>
                                                    <div><?php echo $booking['type_name']; ?> (Room #<?php echo $booking['room_number']; ?>)</div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="text-muted small">Price</div>
                                                    <div class="fw-bold">$<?php echo number_format($booking['total_price'], 2); ?></div>
                                                </div>
                                            </div>
                                            
                                            <div class="d-flex mt-3">
                                                <a href="booking_detail.php?id=<?php echo $booking['booking_id']; ?>" class="btn btn-sm btn-outline-primary me-2">
                                                    <i class="fas fa-eye me-1"></i> View Details
                                                </a>
                                                
                                                <?php if ($booking['check_out_date'] < date('Y-m-d') && $booking['booking_status'] !== 'cancelled'): ?>
                                                    <!-- Show review button for past bookings -->
                                                    <?php
                                                    // Check if user has already reviewed this booking
                                                    $check_review_query = "SELECT * FROM reviews WHERE booking_id = :booking_id AND user_id = :user_id";
                                                    $check_review_stmt = $conn->prepare($check_review_query);
                                                    $check_review_stmt->bindParam(':booking_id', $booking['booking_id']);
                                                    $check_review_stmt->bindParam(':user_id', $_SESSION['user_id']);
                                                    $check_review_stmt->execute();
                                                    $has_review = $check_review_stmt->rowCount() > 0;
                                                    ?>
                                                    
                                                    <?php if ($has_review): ?>
                                                        <a href="reviews.php" class="btn btn-sm btn-success me-2">
                                                            <i class="fas fa-check me-1"></i> Reviewed
                                                        </a>
                                                    <?php else: ?>
                                                        <a href="add_review.php?booking_id=<?php echo $booking['booking_id']; ?>&hotel_id=<?php echo $booking['hotel_id']; ?>" class="btn btn-sm btn-outline-success me-2">
                                                            <i class="fas fa-star me-1"></i> Write a Review
                                                        </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                
                                                <?php if ($booking['check_in_date'] > date('Y-m-d') && $booking['booking_status'] !== 'cancelled'): ?>
                                                    <!-- Show cancel button for future bookings -->
                                                    <a href="cancel_booking.php?id=<?php echo $booking['booking_id']; ?>" 
                                                       class="btn btn-sm btn-outline-danger"
                                                       onclick="return confirm('Are you sure you want to cancel this booking?')">
                                                        <i class="fas fa-times me-1"></i> Cancel
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <div class="mb-3">
                                <i class="fas fa-calendar-times fa-4x text-muted"></i>
                            </div>
                            <h5 class="text-muted">No bookings found</h5>
                            <p>You don't have any bookings matching the selected filters.</p>
                            <a href="../hotels.php" class="btn btn-primary mt-2">Browse Hotels</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
