<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in
checkLoginRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Check if booking ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid booking ID.";
    redirect(SITE_URL . '/user/bookings.php');
}

$booking_id = (int)$_GET['id'];

// Get booking details
$query = "
    SELECT b.*, r.room_number, rt.type_name, rt.description as room_description, 
           rt.price, rt.amenities as room_amenities, rt.max_occupancy,
           h.hotel_id, h.hotel_name, h.location, h.description as hotel_description, 
           h.image_path as hotel_image
    FROM bookings b
    JOIN rooms r ON b.room_id = r.room_id
    JOIN room_types rt ON r.room_type_id = rt.room_type_id
    JOIN hotels h ON rt.hotel_id = h.hotel_id
    WHERE b.booking_id = :booking_id AND b.user_id = :user_id";
    
$stmt = $conn->prepare($query);
$stmt->bindParam(':booking_id', $booking_id);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();

// Check if booking exists and belongs to the user
if ($stmt->rowCount() === 0) {
    $_SESSION['error_message'] = "Booking not found or you don't have permission to view it.";
    redirect(SITE_URL . '/user/bookings.php');
}

$booking = $stmt->fetch(PDO::FETCH_ASSOC);

// Calculate booking details
$check_in = new DateTime($booking['check_in_date']);
$check_out = new DateTime($booking['check_out_date']);
$nights = $check_in->diff($check_out)->days;

// Get user information
$user_query = "SELECT * FROM users WHERE user_id = :user_id";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bindParam(':user_id', $_SESSION['user_id']);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="fas fa-user-circle fa-5x text-secondary"></i>
                    </div>
                    <h5 class="card-title"><?php echo $user['full_name']; ?></h5>
                    <p class="card-text text-muted"><?php echo $user['email']; ?></p>
                </div>
            </div>
            
            <div class="list-group">
                <a href="<?php echo SITE_URL; ?>/user/dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
                <a href="<?php echo SITE_URL; ?>/user/profile.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-user me-2"></i> My Profile
                </a>
                <a href="<?php echo SITE_URL; ?>/user/bookings.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-calendar-check me-2"></i> My Bookings
                </a>
                <a href="<?php echo SITE_URL; ?>/user/reviews.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-star me-2"></i> My Reviews
                </a>
                <a href="<?php echo SITE_URL; ?>/logout.php" class="list-group-item list-group-item-action text-danger">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="mb-0">Booking Details</h1>
                <a href="bookings.php" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left me-2"></i> Back to Bookings
                </a>
            </div>
            
            <!-- Booking Status -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h4>Booking Reference: #<?php echo str_pad($booking['booking_id'], 6, '0', STR_PAD_LEFT); ?></h4>
                            <p class="text-muted mb-0">Booked on <?php echo formatDate($booking['booking_date']); ?></p>
                        </div>
                        <div>
                            <?php
                            $status_class = 'bg-secondary';
                            if ($booking['booking_status'] === 'confirmed') $status_class = 'bg-success';
                            if ($booking['booking_status'] === 'pending') $status_class = 'bg-warning';
                            if ($booking['booking_status'] === 'cancelled') $status_class = 'bg-danger';
                            ?>
                            <span class="badge <?php echo $status_class; ?> fs-6 p-2">
                                <?php echo ucfirst($booking['booking_status']); ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Hotel Information -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-hotel me-2"></i> Hotel Information
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <img src="<?php echo !empty($booking['hotel_image']) ? '../' . $booking['hotel_image'] : '../assets/img/hotel-placeholder.jpg'; ?>" 
                                 class="img-fluid rounded" alt="<?php echo $booking['hotel_name']; ?>">
                        </div>
                        <div class="col-md-8">
                            <h4><?php echo $booking['hotel_name']; ?></h4>
                            <p><i class="fas fa-map-marker-alt me-2"></i> <?php echo $booking['location']; ?></p>
                            <p><?php echo $booking['hotel_description']; ?></p>
                            <a href="../hotel.php?id=<?php echo $booking['hotel_id']; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-external-link-alt me-1"></i> View Hotel
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Room Information -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-bed me-2"></i> Room Information
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5><?php echo $booking['type_name']; ?> (Room #<?php echo $booking['room_number']; ?>)</h5>
                            <p><?php echo $booking['room_description']; ?></p>
                            
                            <?php if (!empty($booking['room_amenities'])): ?>
                                <h6 class="mt-3">Room Amenities:</h6>
                                <ul class="list-group list-group-flush">
                                    <?php foreach (explode(',', $booking['room_amenities']) as $amenity): ?>
                                        <li class="list-group-item border-0 ps-0"><i class="fas fa-check text-success me-2"></i> <?php echo trim($amenity); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <div class="card bg-light">
                                <div class="card-body">
                                    <h6>Booking Summary</h6>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Check-in:</span>
                                        <span class="fw-bold"><?php echo formatDate($booking['check_in_date']); ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Check-out:</span>
                                        <span class="fw-bold"><?php echo formatDate($booking['check_out_date']); ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Duration:</span>
                                        <span><?php echo $nights; ?> night<?php echo $nights > 1 ? 's' : ''; ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Guests:</span>
                                        <span><?php echo $booking['num_guests']; ?></span>
                                    </div>
                                    <hr>
                                    <div class="d-flex justify-content-between">
                                        <span class="fw-bold">Total Price:</span>
                                        <span class="fw-bold">$<?php echo number_format($booking['total_price'], 2); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Actions -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-cog me-2"></i> Booking Actions
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-flex flex-wrap gap-2">
                        <!-- Print button -->
                        <button onclick="window.print();" class="btn btn-outline-secondary">
                            <i class="fas fa-print me-2"></i> Print Booking
                        </button>
                        
                        <?php if ($booking['check_in_date'] > date('Y-m-d') && $booking['booking_status'] !== 'cancelled'): ?>
                            <!-- Cancel button for future bookings -->
                            <a href="cancel_booking.php?id=<?php echo $booking['booking_id']; ?>" 
                               class="btn btn-outline-danger"
                               onclick="return confirm('Are you sure you want to cancel this booking?')">
                                <i class="fas fa-times me-2"></i> Cancel Booking
                            </a>
                        <?php endif; ?>
                        
                        <?php if ($booking['check_out_date'] < date('Y-m-d') && $booking['booking_status'] !== 'cancelled'): ?>
                            <?php
                            // Check if user has already reviewed this booking
                            $check_review_query = "SELECT * FROM reviews WHERE booking_id = :booking_id AND user_id = :user_id";
                            $check_review_stmt = $conn->prepare($check_review_query);
                            $check_review_stmt->bindParam(':booking_id', $booking['booking_id']);
                            $check_review_stmt->bindParam(':user_id', $_SESSION['user_id']);
                            $check_review_stmt->execute();
                            $has_review = $check_review_stmt->rowCount() > 0;
                            ?>
                            
                            <?php if ($has_review): ?>
                                <a href="reviews.php" class="btn btn-success">
                                    <i class="fas fa-check me-2"></i> Reviewed
                                </a>
                            <?php else: ?>
                                <a href="add_review.php?booking_id=<?php echo $booking['booking_id']; ?>&hotel_id=<?php echo $booking['hotel_id']; ?>" class="btn btn-outline-success">
                                    <i class="fas fa-star me-2"></i> Write a Review
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
