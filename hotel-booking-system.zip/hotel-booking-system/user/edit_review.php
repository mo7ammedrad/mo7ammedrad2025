<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in
checkLoginRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Check if review_id is provided
if (!isset($_GET['id'])) {
    $_SESSION['error_message'] = "Missing review ID.";
    redirect(SITE_URL . '/user/reviews.php');
}

$review_id = (int)$_GET['id'];

// Verify the review belongs to the user
$review_query = "
    SELECT r.*, h.hotel_name, h.location, b.check_in_date, b.check_out_date
    FROM reviews r
    JOIN hotels h ON r.hotel_id = h.hotel_id
    LEFT JOIN bookings b ON r.booking_id = b.booking_id
    WHERE r.review_id = :review_id AND r.user_id = :user_id";
    
$review_stmt = $conn->prepare($review_query);
$review_stmt->bindParam(':review_id', $review_id);
$review_stmt->bindParam(':user_id', $_SESSION['user_id']);
$review_stmt->execute();

// If review not found or doesn't belong to user
if ($review_stmt->rowCount() === 0) {
    $_SESSION['error_message'] = "Review not found or you don't have permission to edit it.";
    redirect(SITE_URL . '/user/reviews.php');
}

$review = $review_stmt->fetch(PDO::FETCH_ASSOC);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = (int)$_POST['rating'];
    $comment = cleanInput($_POST['comment']);
    
    // Validate input
    if ($rating < 1 || $rating > 5) {
        $_SESSION['error_message'] = "Invalid rating. Please select a rating between 1 and 5.";
    } elseif (empty($comment)) {
        $_SESSION['error_message'] = "Please provide a review comment.";
    } else {
        // Update the review
        $update_query = "
            UPDATE reviews 
            SET rating = :rating, comment = :comment, review_date = NOW()
            WHERE review_id = :review_id AND user_id = :user_id";
            
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bindParam(':rating', $rating);
        $update_stmt->bindParam(':comment', $comment);
        $update_stmt->bindParam(':review_id', $review_id);
        $update_stmt->bindParam(':user_id', $_SESSION['user_id']);
        
        if ($update_stmt->execute()) {
            $_SESSION['success_message'] = "Your review has been updated successfully.";
            redirect(SITE_URL . '/user/reviews.php');
        } else {
            $_SESSION['error_message'] = "Error updating your review. Please try again.";
        }
    }
}

// Get user information
$user_query = "SELECT * FROM users WHERE user_id = :user_id";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bindParam(':user_id', $_SESSION['user_id']);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="fas fa-user-circle fa-5x text-secondary"></i>
                    </div>
                    <h5 class="card-title"><?php echo $user['full_name']; ?></h5>
                    <p class="card-text text-muted"><?php echo $user['email']; ?></p>
                </div>
            </div>
            
            <div class="list-group">
                <a href="<?php echo SITE_URL; ?>/user/dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
                <a href="<?php echo SITE_URL; ?>/user/profile.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-user me-2"></i> My Profile
                </a>
                <a href="<?php echo SITE_URL; ?>/user/bookings.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-calendar-check me-2"></i> My Bookings
                </a>
                <a href="<?php echo SITE_URL; ?>/user/reviews.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-star me-2"></i> My Reviews
                </a>
                <a href="<?php echo SITE_URL; ?>/logout.php" class="list-group-item list-group-item-action text-danger">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <h1 class="mb-4">
                <i class="fas fa-edit me-2"></i> Edit Review
            </h1>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Editing Review for <?php echo $review['hotel_name']; ?></h5>
                </div>
                <div class="card-body">
                    <p>You're editing your review of <strong><?php echo $review['hotel_name']; ?></strong> in <?php echo $review['location']; ?></p>
                    <?php if (!empty($review['check_in_date']) && !empty($review['check_out_date'])): ?>
                        <p class="text-muted">Stay dates: <?php echo formatDate($review['check_in_date']); ?> to <?php echo formatDate($review['check_out_date']); ?></p>
                    <?php endif; ?>
                    
                    <form action="edit_review.php?id=<?php echo $review_id; ?>" method="POST">
                        <div class="mb-4">
                            <label class="form-label">Your Rating</label>
                            <div class="rating-stars-input mb-2">
                                <div class="btn-group" role="group" aria-label="Rating">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <input type="radio" class="btn-check" name="rating" id="rating<?php echo $i; ?>" value="<?php echo $i; ?>" <?php echo $review['rating'] == $i ? 'checked' : ''; ?> required>
                                        <label class="btn btn-outline-warning" for="rating<?php echo $i; ?>">
                                            <i class="fas fa-star"></i> <?php echo $i; ?>
                                        </label>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="comment" class="form-label">Your Review</label>
                            <textarea class="form-control" id="comment" name="comment" rows="5" required><?php echo htmlspecialchars($review['comment']); ?></textarea>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="reviews.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i> Back to Reviews
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i> Update Review
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
