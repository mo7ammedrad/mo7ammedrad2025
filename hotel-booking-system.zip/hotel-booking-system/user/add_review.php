<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in
checkLoginRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Check if booking_id and hotel_id are provided
if (!isset($_GET['booking_id']) || !isset($_GET['hotel_id'])) {
    $_SESSION['error_message'] = "Missing required parameters.";
    redirect(SITE_URL . '/user/bookings.php');
}

$booking_id = (int)$_GET['booking_id'];
$hotel_id = (int)$_GET['hotel_id'];

// Verify the booking belongs to the user and is completed
$booking_query = "
    SELECT b.*, h.hotel_name, h.location
    FROM bookings b
    JOIN rooms r ON b.room_id = r.room_id
    JOIN room_types rt ON r.room_type_id = rt.room_type_id
    JOIN hotels h ON rt.hotel_id = h.hotel_id
    WHERE b.booking_id = :booking_id 
    AND b.user_id = :user_id 
    AND b.booking_status = 'completed'
    AND h.hotel_id = :hotel_id";
    
$booking_stmt = $conn->prepare($booking_query);
$booking_stmt->bindParam(':booking_id', $booking_id);
$booking_stmt->bindParam(':user_id', $_SESSION['user_id']);
$booking_stmt->bindParam(':hotel_id', $hotel_id);
$booking_stmt->execute();

// If booking not found or not eligible for review
if ($booking_stmt->rowCount() === 0) {
    $_SESSION['error_message'] = "Booking not found or not eligible for review.";
    redirect(SITE_URL . '/user/bookings.php');
}

$booking = $booking_stmt->fetch(PDO::FETCH_ASSOC);

// Check if user has already reviewed this booking
$check_query = "SELECT * FROM reviews WHERE booking_id = :booking_id AND user_id = :user_id";
$check_stmt = $conn->prepare($check_query);
$check_stmt->bindParam(':booking_id', $booking_id);
$check_stmt->bindParam(':user_id', $_SESSION['user_id']);
$check_stmt->execute();

if ($check_stmt->rowCount() > 0) {
    $_SESSION['error_message'] = "You have already reviewed this booking.";
    redirect(SITE_URL . '/user/reviews.php');
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = (int)$_POST['rating'];
    $comment = cleanInput($_POST['comment']);
    
    // Validate input
    if ($rating < 1 || $rating > 5) {
        $_SESSION['error_message'] = "Invalid rating. Please select a rating between 1 and 5.";
    } elseif (empty($comment)) {
        $_SESSION['error_message'] = "Please provide a review comment.";
    } else {
        // Insert the review
        $insert_query = "
            INSERT INTO reviews (user_id, hotel_id, booking_id, rating, comment, review_date)
            VALUES (:user_id, :hotel_id, :booking_id, :rating, :comment, NOW())";
            
        $insert_stmt = $conn->prepare($insert_query);
        $insert_stmt->bindParam(':user_id', $_SESSION['user_id']);
        $insert_stmt->bindParam(':hotel_id', $hotel_id);
        $insert_stmt->bindParam(':booking_id', $booking_id);
        $insert_stmt->bindParam(':rating', $rating);
        $insert_stmt->bindParam(':comment', $comment);
        
        if ($insert_stmt->execute()) {
            $_SESSION['success_message'] = "Your review has been submitted successfully.";
            redirect(SITE_URL . '/user/reviews.php');
        } else {
            $_SESSION['error_message'] = "Error submitting your review. Please try again.";
        }
    }
}

// Get user information
$user_query = "SELECT * FROM users WHERE user_id = :user_id";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bindParam(':user_id', $_SESSION['user_id']);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="fas fa-user-circle fa-5x text-secondary"></i>
                    </div>
                    <h5 class="card-title"><?php echo $user['full_name']; ?></h5>
                    <p class="card-text text-muted"><?php echo $user['email']; ?></p>
                </div>
            </div>
            
            <div class="list-group">
                <a href="<?php echo SITE_URL; ?>/user/dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
                <a href="<?php echo SITE_URL; ?>/user/profile.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-user me-2"></i> My Profile
                </a>
                <a href="<?php echo SITE_URL; ?>/user/bookings.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-calendar-check me-2"></i> My Bookings
                </a>
                <a href="<?php echo SITE_URL; ?>/user/reviews.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-star me-2"></i> My Reviews
                </a>
                <a href="<?php echo SITE_URL; ?>/logout.php" class="list-group-item list-group-item-action text-danger">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <h1 class="mb-4">
                <i class="fas fa-star me-2"></i> Write a Review
            </h1>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Review for <?php echo $booking['hotel_name']; ?></h5>
                </div>
                <div class="card-body">
                    <p>You're reviewing your stay at <strong><?php echo $booking['hotel_name']; ?></strong> in <?php echo $booking['location']; ?></p>
                    <p class="text-muted">Stay dates: <?php echo formatDate($booking['check_in_date']); ?> to <?php echo formatDate($booking['check_out_date']); ?></p>
                    
                    <form action="add_review.php?booking_id=<?php echo $booking_id; ?>&hotel_id=<?php echo $hotel_id; ?>" method="POST">
                        <div class="mb-4">
                            <label class="form-label">Your Rating</label>
                            <div class="rating-stars-input mb-2">
                                <div class="btn-group" role="group" aria-label="Rating">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <input type="radio" class="btn-check" name="rating" id="rating<?php echo $i; ?>" value="<?php echo $i; ?>" required>
                                        <label class="btn btn-outline-warning" for="rating<?php echo $i; ?>">
                                            <i class="fas fa-star"></i> <?php echo $i; ?>
                                        </label>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="comment" class="form-label">Your Review</label>
                            <textarea class="form-control" id="comment" name="comment" rows="5" placeholder="Share your experience with this hotel..." required></textarea>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="bookings.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i> Back to Bookings
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane me-2"></i> Submit Review
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
