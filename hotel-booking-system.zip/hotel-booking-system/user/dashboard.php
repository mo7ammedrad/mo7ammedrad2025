
<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in
checkLoginRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Get user information
$user_query = "SELECT * FROM users WHERE user_id = :user_id";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bindParam(':user_id', $_SESSION['user_id']);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

// Get user's recent bookings
$bookings_query = "
    SELECT b.*, r.room_number, rt.type_name, rt.price,
           h.hotel_name, h.location, h.image_path as hotel_image
    FROM bookings b
    JOIN rooms r ON b.room_id = r.room_id
    JOIN room_types rt ON r.room_type_id = rt.room_type_id
    JOIN hotels h ON rt.hotel_id = h.hotel_id
    WHERE b.user_id = :user_id
    ORDER BY b.booking_date DESC
    LIMIT 3";

$bookings_stmt = $conn->prepare($bookings_query);
$bookings_stmt->bindParam(':user_id', $_SESSION['user_id']);
$bookings_stmt->execute();
$recent_bookings = $bookings_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get booking statistics
$stats_query = "
    SELECT 
        COUNT(*) as total_bookings,
        SUM(CASE WHEN check_in_date > CURRENT_DATE THEN 1 ELSE 0 END) as upcoming_bookings,
        SUM(CASE WHEN check_out_date < CURRENT_DATE THEN 1 ELSE 0 END) as past_bookings,
        SUM(total_price) as total_spent
    FROM bookings 
    WHERE user_id = :user_id";

$stats_stmt = $conn->prepare($stats_query);
$stats_stmt->bindParam(':user_id', $_SESSION['user_id']);
$stats_stmt->execute();
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="fas fa-user-circle fa-5x text-secondary"></i>
                    </div>
                    <h5 class="card-title"><?php echo $user['full_name']; ?></h5>
                    <p class="card-text text-muted"><?php echo $user['email']; ?></p>
                </div>
            </div>
            
            <div class="list-group">
                <a href="dashboard.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
                <a href="profile.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-user me-2"></i> My Profile
                </a>
                <a href="bookings.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-calendar-check me-2"></i> My Bookings
                </a>
                <a href="reviews.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-star me-2"></i> My Reviews
                </a>
                <a href="../logout.php" class="list-group-item list-group-item-action text-danger">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <h1 class="mb-4">User Dashboard</h1>
            
            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card dashboard-card text-center h-100">
                        <div class="card-body">
                            <div class="icon mb-2">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                            <h5 class="card-title">Total Bookings</h5>
                            <h3><?php echo $stats['total_bookings']; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card dashboard-card text-center h-100">
                        <div class="card-body">
                            <div class="icon mb-2">
                                <i class="fas fa-hourglass-start"></i>
                            </div>
                            <h5 class="card-title">Upcoming Stays</h5>
                            <h3><?php echo $stats['upcoming_bookings']; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card dashboard-card text-center h-100">
                        <div class="card-body">
                            <div class="icon mb-2">
                                <i class="fas fa-money-bill-wave"></i>
                            </div>
                            <h5 class="card-title">Total Spent</h5>
                            <h3>$<?php echo number_format($stats['total_spent'], 2); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Bookings -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Bookings</h5>
                    <a href="bookings.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body">
                    <?php if (count($recent_bookings) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Hotel</th>
                                        <th>Room</th>
                                        <th>Dates</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_bookings as $booking): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <img src="<?php echo !empty($booking['hotel_image']) ? '../' . $booking['hotel_image'] : '../assets/img/hotel-placeholder.jpg'; ?>" 
                                                         class="me-2" alt="Hotel" style="width: 40px; height: 40px; object-fit: cover;">
                                                    <div>
                                                        <div><?php echo $booking['hotel_name']; ?></div>
                                                        <small class="text-muted"><?php echo $booking['location']; ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div><?php echo $booking['type_name']; ?></div>
                                                <small class="text-muted">Room <?php echo $booking['room_number']; ?></small>
                                            </td>
                                            <td>
                                                <div><?php echo formatDate($booking['check_in_date']); ?></div>
                                                <small class="text-muted">to <?php echo formatDate($booking['check_out_date']); ?></small>
                                            </td>
                                            <td>
                                                <?php
                                                $status_class = 'secondary';
                                                if ($booking['booking_status'] === 'confirmed') {
                                                    $status_class = 'success';
                                                } elseif ($booking['booking_status'] === 'cancelled') {
                                                    $status_class = 'danger';
                                                } elseif ($booking['booking_status'] === 'pending') {
                                                    $status_class = 'warning';
                                                }
                                                ?>
                                                <span class="badge bg-<?php echo $status_class; ?>">
                                                    <?php echo ucfirst($booking['booking_status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="../booking_details.php?id=<?php echo $booking['booking_id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">You don't have any bookings yet.</p>
                        <a href="../hotels.php" class="btn btn-primary">Find a Hotel</a>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Recommended Hotels -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Recommended Hotels</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php
                        // Get recommended hotels
                        $recommended_query = "
                            SELECT h.*, AVG(r.rating) as average_rating
                            FROM hotels h
                            LEFT JOIN reviews r ON h.hotel_id = r.hotel_id
                            GROUP BY h.hotel_id
                            ORDER BY average_rating DESC, h.hotel_id ASC
                            LIMIT 3";
                            
                        $recommended_stmt = $conn->prepare($recommended_query);
                        $recommended_stmt->execute();
                        $recommended_hotels = $recommended_stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        if (count($recommended_hotels) > 0):
                            foreach ($recommended_hotels as $hotel):
                        ?>
                            <div class="col-md-4 mb-3">
                                <div class="card h-100">
                                    <img src="<?php echo !empty($hotel['image_path']) ? '../' . $hotel['image_path'] : '../assets/img/hotel-placeholder.jpg'; ?>" 
                                         class="card-img-top" alt="<?php echo $hotel['hotel_name']; ?>" style="height: 100px; object-fit: cover;">
                                    <div class="card-body">
                                        <h6 class="card-title"><?php echo $hotel['hotel_name']; ?></h6>
                                        <p class="card-text text-muted small"><?php echo $hotel['location']; ?></p>
                                        <div class="small mb-2">
                                            <?php 
                                            $rating = round($hotel['average_rating'], 1);
                                            for ($i = 1; $i <= 5; $i++) {
                                                if ($i <= $rating) {
                                                    echo '<i class="fas fa-star rating-stars"></i>';
                                                } else if ($i - 0.5 <= $rating) {
                                                    echo '<i class="fas fa-star-half-alt rating-stars"></i>';
                                                } else {
                                                    echo '<i class="far fa-star rating-stars"></i>';
                                                }
                                            }
                                            ?>
                                        </div>
                                        <a href="../hotel_details.php?id=<?php echo $hotel['hotel_id']; ?>" class="btn btn-sm btn-outline-primary">View Details</a>
                                    </div>
                                </div>
                            </div>
                        <?php
                            endforeach;
                        else:
                        ?>
                            <div class="col-12">
                                <p class="text-muted">No recommended hotels at the moment.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
