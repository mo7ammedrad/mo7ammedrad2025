<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in
checkLoginRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Handle review deletion
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $review_id = (int)$_GET['delete'];
    
    // Verify the review belongs to the user
    $check_query = "SELECT * FROM reviews WHERE review_id = :review_id AND user_id = :user_id";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bindParam(':review_id', $review_id);
    $check_stmt->bindParam(':user_id', $_SESSION['user_id']);
    $check_stmt->execute();
    
    if ($check_stmt->rowCount() > 0) {
        // Delete the review
        $delete_query = "DELETE FROM reviews WHERE review_id = :review_id";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->bindParam(':review_id', $review_id);
        
        if ($delete_stmt->execute()) {
            $_SESSION['success_message'] = "Your review has been deleted successfully.";
        } else {
            $_SESSION['error_message'] = "Error deleting your review. Please try again.";
        }
    } else {
        $_SESSION['error_message'] = "Review not found or you don't have permission to delete it.";
    }
    
    // Redirect to avoid resubmission
    redirect(SITE_URL . '/user/reviews.php');
}

// Get user's reviews
$query = "
    SELECT r.*, h.hotel_name, h.location, h.image_path as hotel_image
    FROM reviews r
    JOIN hotels h ON r.hotel_id = h.hotel_id
    WHERE r.user_id = :user_id
    ORDER BY r.review_date DESC";
$stmt = $conn->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user information
$user_query = "SELECT * FROM users WHERE user_id = :user_id";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bindParam(':user_id', $_SESSION['user_id']);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="fas fa-user-circle fa-5x text-secondary"></i>
                    </div>
                    <h5 class="card-title"><?php echo $user['full_name']; ?></h5>
                    <p class="card-text text-muted"><?php echo $user['email']; ?></p>
                </div>
            </div>
            
            <div class="list-group">
                <a href="<?php echo SITE_URL; ?>/user/dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
                <a href="<?php echo SITE_URL; ?>/user/profile.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-user me-2"></i> My Profile
                </a>
                <a href="<?php echo SITE_URL; ?>/user/bookings.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-calendar-check me-2"></i> My Bookings
                </a>
                <a href="<?php echo SITE_URL; ?>/user/reviews.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-star me-2"></i> My Reviews
                </a>
                <a href="<?php echo SITE_URL; ?>/logout.php" class="list-group-item list-group-item-action text-danger">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="mb-0">My Reviews</h1>
                <div>
                    <a href="bookings.php?status=completed" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i> Write New Review
                    </a>
                </div>
            </div>
            
            <!-- Reviews List -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-star me-2"></i> Your Reviews
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (count($reviews) > 0): ?>
                        <?php foreach ($reviews as $review): ?>
                            <div class="card mb-3 shadow-sm">
                                <div class="row g-0">
                                    <div class="col-md-3">
                                        <img src="<?php echo !empty($review['hotel_image']) ? '../' . $review['hotel_image'] : '../assets/img/hotel-placeholder.jpg'; ?>" 
                                             class="img-fluid rounded-start h-100" alt="<?php echo $review['hotel_name']; ?>" style="object-fit: cover;">
                                    </div>
                                    <div class="col-md-9">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between">
                                                <h5 class="card-title"><?php echo $review['hotel_name']; ?></h5>
                                                <div>
                                                    <a href="edit_review.php?id=<?php echo $review['review_id']; ?>" class="btn btn-sm btn-primary me-2">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </a>
                                                    <a href="reviews.php?delete=<?php echo $review['review_id']; ?>" 
                                                       class="btn btn-sm btn-danger"
                                                       onclick="return confirm('Are you sure you want to delete this review?')">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </a>
                                                </div>
                                            </div>
                                            
                                            <p class="card-text text-muted small mb-2"><?php echo $review['location']; ?></p>
                                            
                                            <div class="rating-stars mb-2">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <i class="fas fa-star <?php echo $i <= $review['rating'] ? 'text-warning' : 'text-muted'; ?>"></i>
                                                <?php endfor; ?>
                                                <span class="ms-2"><?php echo formatDate($review['review_date']); ?></span>
                                            </div>
                                            
                                            <p class="card-text"><?php echo nl2br(htmlspecialchars($review['comment'])); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <div class="mb-3">
                                <i class="fas fa-comment-slash fa-4x text-muted"></i>
                            </div>
                            <h5 class="text-muted">No reviews yet</h5>
                            <p>You haven't written any reviews. After completing a stay, you can share your experience!</p>
                            <a href="bookings.php?status=completed" class="btn btn-primary mt-2">Check Completed Bookings</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
