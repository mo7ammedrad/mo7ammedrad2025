<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in
checkLoginRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Check if booking ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid booking ID.";
    redirect(SITE_URL . '/user/bookings.php');
}

$booking_id = (int)$_GET['id'];

// Verify the booking belongs to the user and is eligible for cancellation
$query = "
    SELECT b.*, h.hotel_name
    FROM bookings b
    JOIN rooms r ON b.room_id = r.room_id
    JOIN room_types rt ON r.room_type_id = rt.room_type_id
    JOIN hotels h ON rt.hotel_id = h.hotel_id
    WHERE b.booking_id = :booking_id 
    AND b.user_id = :user_id 
    AND b.check_in_date > CURRENT_DATE
    AND b.booking_status != 'cancelled'";
    
$stmt = $conn->prepare($query);
$stmt->bindParam(':booking_id', $booking_id);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();

// If booking not found or not eligible for cancellation
if ($stmt->rowCount() === 0) {
    $_SESSION['error_message'] = "Booking not found, already cancelled, or past the cancellation period.";
    redirect(SITE_URL . '/user/bookings.php');
}

$booking = $stmt->fetch(PDO::FETCH_ASSOC);

// Process cancellation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_cancel'])) {
    $cancellation_reason = isset($_POST['cancellation_reason']) ? cleanInput($_POST['cancellation_reason']) : 'No reason provided';
    
    // Update booking status
    $update_query = "
        UPDATE bookings
        SET booking_status = 'cancelled', 
            cancellation_reason = :cancellation_reason,
            cancellation_date = NOW()
        WHERE booking_id = :booking_id";
        
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bindParam(':booking_id', $booking_id);
    $update_stmt->bindParam(':cancellation_reason', $cancellation_reason);
    
    if ($update_stmt->execute()) {
        $_SESSION['success_message'] = "Your booking has been cancelled successfully.";
        
        // In a real application, you might send confirmation emails here
        // and handle refunds if applicable
        
        redirect(SITE_URL . '/user/bookings.php');
    } else {
        $_SESSION['error_message'] = "Error cancelling your booking. Please try again.";
    }
}

// Get user information
$user_query = "SELECT * FROM users WHERE user_id = :user_id";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bindParam(':user_id', $_SESSION['user_id']);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

// Include header
include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="fas fa-user-circle fa-5x text-secondary"></i>
                    </div>
                    <h5 class="card-title"><?php echo $user['full_name']; ?></h5>
                    <p class="card-text text-muted"><?php echo $user['email']; ?></p>
                </div>
            </div>
            
            <div class="list-group">
                <a href="<?php echo SITE_URL; ?>/user/dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
                <a href="<?php echo SITE_URL; ?>/user/profile.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-user me-2"></i> My Profile
                </a>
                <a href="<?php echo SITE_URL; ?>/user/bookings.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-calendar-check me-2"></i> My Bookings
                </a>
                <a href="<?php echo SITE_URL; ?>/user/reviews.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-star me-2"></i> My Reviews
                </a>
                <a href="<?php echo SITE_URL; ?>/logout.php" class="list-group-item list-group-item-action text-danger">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="mb-0">Cancel Booking</h1>
                <a href="bookings.php" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left me-2"></i> Back to Bookings
                </a>
            </div>
            
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-exclamation-triangle me-2"></i> Cancel Booking Confirmation
                    </h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-warning">
                        <h5 class="alert-heading">Please confirm your cancellation!</h5>
                        <p>You are about to cancel your booking at <strong><?php echo $booking['hotel_name']; ?></strong>.</p>
                        <p>Booking details:</p>
                        <ul>
                            <li>Check-in date: <?php echo formatDate($booking['check_in_date']); ?></li>
                            <li>Check-out date: <?php echo formatDate($booking['check_out_date']); ?></li>
                            <li>Total price: $<?php echo number_format($booking['total_price'], 2); ?></li>
                        </ul>
                        <p>Please note that cancellation policies may apply. Depending on the hotel's policy, you may be eligible for a full or partial refund.</p>
                    </div>
                    
                    <form action="cancel_booking.php?id=<?php echo $booking_id; ?>" method="POST">
                        <div class="mb-3">
                            <label for="cancellation_reason" class="form-label">Reason for Cancellation (Optional)</label>
                            <textarea class="form-control" id="cancellation_reason" name="cancellation_reason" rows="3" placeholder="Please provide a reason for cancelling your booking..."></textarea>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="bookings.php" class="btn btn-secondary">
                                <i class="fas fa-times me-2"></i> No, Keep My Booking
                            </a>
                            <button type="submit" name="confirm_cancel" class="btn btn-danger">
                                <i class="fas fa-check me-2"></i> Yes, Cancel Booking
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
