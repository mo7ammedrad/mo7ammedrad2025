
<?php
// Include the configuration file
require_once '../config/config.php';

// Check if the user is logged in
checkLoginRedirect();

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Get user information
$user_query = "SELECT * FROM users WHERE user_id = :user_id";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bindParam(':user_id', $_SESSION['user_id']);
$user_stmt->execute();
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);

// Handle profile update
$update_success = false;
$update_error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = cleanInput($_POST['full_name']);
    $email = cleanInput($_POST['email']);
    $phone = isset($_POST['phone']) ? cleanInput($_POST['phone']) : '';
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $update_error = "Invalid email format";
    } else {
        // Check if email is already taken by another user
        $check_email_query = "SELECT user_id FROM users WHERE email = :email AND user_id != :user_id";
        $check_email_stmt = $conn->prepare($check_email_query);
        $check_email_stmt->bindParam(':email', $email);
        $check_email_stmt->bindParam(':user_id', $_SESSION['user_id']);
        $check_email_stmt->execute();
        
        if ($check_email_stmt->rowCount() > 0) {
            $update_error = "Email is already in use by another account";
        } else {
            // Update the user profile
            $update_query = "UPDATE users SET full_name = :full_name, email = :email, phone = :phone WHERE user_id = :user_id";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bindParam(':full_name', $full_name);
            $update_stmt->bindParam(':email', $email);
            $update_stmt->bindParam(':phone', $phone);
            $update_stmt->bindParam(':user_id', $_SESSION['user_id']);
            
            if ($update_stmt->execute()) {
                $update_success = true;
                
                // Update user information
                $user_stmt->execute();
                $user = $user_stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                $update_error = "Error updating profile. Please try again.";
            }
        }
    }
}

// Handle password update
$password_success = false;
$password_error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_password'])) {
    $current_password = cleanInput($_POST['current_password']);
    $new_password = cleanInput($_POST['new_password']);
    $confirm_password = cleanInput($_POST['confirm_password']);
    
    // Validate passwords
    if (strlen($new_password) < 6) {
        $password_error = "New password must be at least 6 characters long";
    } elseif ($new_password !== $confirm_password) {
        $password_error = "New passwords do not match";
    } else {
        // For the admin user with hardcoded password
        if ($user['username'] === 'admin' && $current_password === 'admin123') {
            // Set the new password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $update_pwd_query = "UPDATE users SET password = :password WHERE user_id = :user_id";
            $update_pwd_stmt = $conn->prepare($update_pwd_query);
            $update_pwd_stmt->bindParam(':password', $hashed_password);
            $update_pwd_stmt->bindParam(':user_id', $_SESSION['user_id']);
            
            if ($update_pwd_stmt->execute()) {
                $password_success = true;
            } else {
                $password_error = "Error updating password. Please try again.";
            }
        }
        // For regular users, verify current password
        elseif (password_verify($current_password, $user['password'])) {
            // Set the new password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $update_pwd_query = "UPDATE users SET password = :password WHERE user_id = :user_id";
            $update_pwd_stmt = $conn->prepare($update_pwd_query);
            $update_pwd_stmt->bindParam(':password', $hashed_password);
            $update_pwd_stmt->bindParam(':user_id', $_SESSION['user_id']);
            
            if ($update_pwd_stmt->execute()) {
                $password_success = true;
            } else {
                $password_error = "Error updating password. Please try again.";
            }
        } else {
            $password_error = "Current password is incorrect";
        }
    }
}

// Include header
include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="fas fa-user-circle fa-5x text-secondary"></i>
                    </div>
                    <h5 class="card-title"><?php echo $user['full_name']; ?></h5>
                    <p class="card-text text-muted"><?php echo $user['email']; ?></p>
                </div>
            </div>
            
            <div class="list-group">
                <a href="dashboard.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
                <a href="profile.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-user me-2"></i> My Profile
                </a>
                <a href="bookings.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-calendar-check me-2"></i> My Bookings
                </a>
                <a href="reviews.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-star me-2"></i> My Reviews
                </a>
                <a href="../logout.php" class="list-group-item list-group-item-action text-danger">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <h1 class="mb-4">My Profile</h1>
            
            <!-- Profile Information -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-user me-2"></i> Personal Information
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($update_success): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i> Profile updated successfully!
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($update_error)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i> <?php echo $update_error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form action="profile.php" method="POST">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" value="<?php echo $user['username']; ?>" readonly>
                            <small class="form-text text-muted">Username cannot be changed</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="full_name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo $user['full_name']; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone (optional)</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $user['phone']; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">User Type</label>
                            <input type="text" class="form-control" value="<?php echo ucfirst($user['user_type']); ?>" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Registration Date</label>
                            <input type="text" class="form-control" value="<?php echo date('F d, Y', strtotime($user['created_at'])); ?>" readonly>
                        </div>
                        
                        <button type="submit" name="update_profile" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Update Profile
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Password Update -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-lock me-2"></i> Change Password
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($password_success): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i> Password updated successfully!
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($password_error)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i> <?php echo $password_error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form action="profile.php" method="POST">
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password</label>
                            <input type="password" class="form-control" id="current_password" name="current_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                            <small class="form-text text-muted">Password must be at least 6 characters long</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        
                        <button type="submit" name="update_password" class="btn btn-primary">
                            <i class="fas fa-key me-2"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
