<?php
// Include the configuration file
require_once 'config/config.php';

// Create database connection
$database = new Database();
$conn = $database->getConnection();

// Get featured hotels (highest rated)
$featured_query = "
    SELECT h.*, AVG(r.rating) as average_rating, COUNT(r.review_id) as review_count
    FROM hotels h
    LEFT JOIN reviews r ON h.hotel_id = r.hotel_id
    GROUP BY h.hotel_id
    ORDER BY average_rating DESC
    LIMIT 4";
    
$featured_stmt = $conn->prepare($featured_query);
$featured_stmt->execute();
$featured_hotels = $featured_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get latest hotels (most recently added)
$latest_query = "
    SELECT h.*, AVG(r.rating) as average_rating, COUNT(r.review_id) as review_count
    FROM hotels h
    LEFT JOIN reviews r ON h.hotel_id = r.hotel_id
    GROUP BY h.hotel_id
    ORDER BY h.created_at DESC
    LIMIT 4";
    
$latest_stmt = $conn->prepare($latest_query);
$latest_stmt->execute();
$latest_hotels = $latest_stmt->fetchAll(PDO::FETCH_ASSOC);

// Include header
require_once 'includes/header.php';
?>

<!-- Hero Section -->
<div class="hero-section bg-primary text-white py-5" style="background-image: url('assets/img/hero-bg.jpg'); background-size: cover; background-position: center;">
    <div class="container py-5">
        <div class="row py-5">
            <div class="col-lg-8 col-md-10">
                <h1 class="display-4 fw-bold mb-3">Find Your Perfect Stay</h1>
                <p class="lead mb-4">Discover the best hotels at the best prices. Book your dream accommodation instantly with HotelHaven.</p>
                
                <div class="card">
                    <div class="card-body">
                        <form action="hotels.php" method="GET">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label for="destination" class="form-label">Destination</label>
                                    <input type="text" class="form-control" id="destination" name="location" placeholder="Where are you going?">
                                </div>
                                <div class="col-md-2">
                                    <label for="check_in" class="form-label">Check-in</label>
                                    <input type="date" class="form-control" id="check_in" name="check_in" min="<?php echo date('Y-m-d'); ?>">
                                </div>
                                <div class="col-md-2">
                                    <label for="check_out" class="form-label">Check-out</label>
                                    <input type="date" class="form-control" id="check_out" name="check_out" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                                </div>
                                <div class="col-md-2">
                                    <label for="guests" class="form-label">Guests</label>
                                    <select class="form-select" id="guests" name="guests">
                                        <?php for ($i = 1; $i <= 10; $i++): ?>
                                            <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-2 d-flex align-items-end">
                                    <button type="submit" class="btn btn-success w-100">Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Featured Hotels Section -->
<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Featured Hotels</h2>
            <p class="text-muted">Discover our highest-rated accommodations</p>
        </div>
        <div class="col-md-4 text-md-end">
            <a href="hotels.php" class="btn btn-outline-primary">View All Hotels</a>
        </div>
    </div>
    
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        <?php foreach ($featured_hotels as $hotel): ?>
            <div class="col">
                <div class="card h-100 shadow-sm hotel-card">
                    <img src="<?php echo !empty($hotel['image_path']) ? $hotel['image_path'] : 'assets/img/hotel-placeholder.jpg'; ?>" 
                         class="card-img-top" alt="<?php echo $hotel['hotel_name']; ?>" style="height: 180px; object-fit: cover;">
                    
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $hotel['hotel_name']; ?></h5>
                        <div class="d-flex align-items-center mb-2">
                            <span class="me-2"><i class="fas fa-map-marker-alt text-muted"></i></span>
                            <span class="text-muted small"><?php echo $hotel['location']; ?></span>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <?php
                            $avg_rating = isset($hotel['average_rating']) ? $hotel['average_rating'] : 0;
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= floor($avg_rating)) {
                                    echo '<i class="fas fa-star text-warning me-1"></i>';
                                } elseif ($i - 0.5 <= $avg_rating) {
                                    echo '<i class="fas fa-star-half-alt text-warning me-1"></i>';
                                } else {
                                    echo '<i class="far fa-star text-warning me-1"></i>';
                                }
                            }
                            ?>
                            <span class="ms-1">
                                <?php echo number_format($avg_rating, 1); ?>
                                <small class="text-muted">(<?php echo $hotel['review_count']; ?>)</small>
                            </span>
                        </div>
                        <p class="card-text small mb-3 text-truncate"><?php echo $hotel['description']; ?></p>
                        <a href="hotel.php?id=<?php echo $hotel['hotel_id']; ?>" class="btn btn-outline-primary btn-sm">View Details</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Why Choose Us Section -->
<div class="bg-light py-5">
    <div class="container">
        <h2 class="text-center mb-5">Why Choose HotelHaven?</h2>
        
        <div class="row g-4">
            <div class="col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-hotel text-white fa-2x"></i>
                        </div>
                        <h5 class="card-title">Wide Selection</h5>
                        <p class="card-text text-muted">Over 10,000 hotels across 100 countries to choose from</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-medal text-white fa-2x"></i>
                        </div>
                        <h5 class="card-title">Best Price Guarantee</h5>
                        <p class="card-text text-muted">We offer the best prices with no hidden fees or charges</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-headset text-white fa-2x"></i>
                        </div>
                        <h5 class="card-title">24/7 Support</h5>
                        <p class="card-text text-muted">Our customer service team is available round the clock</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-shield-alt text-white fa-2x"></i>
                        </div>
                        <h5 class="card-title">Secure Booking</h5>
                        <p class="card-text text-muted">Your data and transactions are protected with industry-standard security</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Latest Hotels Section -->
<div class="container py-5">
    <div class="row mb-4">
        <div class="col">
            <h2>Latest Hotels</h2>
            <p class="text-muted">Explore our newest hotel additions</p>
        </div>
    </div>
    
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        <?php foreach ($latest_hotels as $hotel): ?>
            <div class="col">
                <div class="card h-100 shadow-sm hotel-card">
                    <img src="<?php echo !empty($hotel['image_path']) ? $hotel['image_path'] : 'assets/img/hotel-placeholder.jpg'; ?>" 
                         class="card-img-top" alt="<?php echo $hotel['hotel_name']; ?>" style="height: 180px; object-fit: cover;">
                    
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $hotel['hotel_name']; ?></h5>
                        <div class="d-flex align-items-center mb-2">
                            <span class="me-2"><i class="fas fa-map-marker-alt text-muted"></i></span>
                            <span class="text-muted small"><?php echo $hotel['location']; ?></span>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <?php
                            $avg_rating = isset($hotel['average_rating']) ? $hotel['average_rating'] : 0;
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= floor($avg_rating)) {
                                    echo '<i class="fas fa-star text-warning me-1"></i>';
                                } elseif ($i - 0.5 <= $avg_rating) {
                                    echo '<i class="fas fa-star-half-alt text-warning me-1"></i>';
                                } else {
                                    echo '<i class="far fa-star text-warning me-1"></i>';
                                }
                            }
                            ?>
                            <span class="ms-1">
                                <?php echo number_format($avg_rating, 1); ?>
                                <small class="text-muted">(<?php echo $hotel['review_count']; ?>)</small>
                            </span>
                        </div>
                        <p class="card-text small mb-3 text-truncate"><?php echo $hotel['description']; ?></p>
                        <a href="hotel.php?id=<?php echo $hotel['hotel_id']; ?>" class="btn btn-outline-primary btn-sm">View Details</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Testimonials Section -->
<div class="bg-light py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2>What Our Customers Say</h2>
            <p class="text-muted">Don't just take our word for it</p>
        </div>
        
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card border-0 shadow">
                    <div class="card-body p-4">
                        <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <div class="text-center">
                                        <img src="assets/img/testimonial-1.jpg" class="rounded-circle mb-3" width="80" height="80" alt="Customer Testimonial">
                                        <p class="lead">"HotelHaven made my business trip planning so much easier. The interface is intuitive and I found exactly what I needed within minutes."</p>
                                        <div class="d-flex justify-content-center mt-3">
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                        </div>
                                        <h5 class="mt-2 mb-0">Sarah Johnson</h5>
                                        <p class="text-muted small">Business Traveler</p>
                                    </div>
                                </div>
                                
                                <div class="carousel-item">
                                    <div class="text-center">
                                        <img src="assets/img/testimonial-2.jpg" class="rounded-circle mb-3" width="80" height="80" alt="Customer Testimonial">
                                        <p class="lead">"Finding family-friendly accommodations used to be a hassle until I discovered HotelHaven. The filters are spot on and the booking process is seamless."</p>
                                        <div class="d-flex justify-content-center mt-3">
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                        </div>
                                        <h5 class="mt-2 mb-0">Michael Chen</h5>
                                        <p class="text-muted small">Family Vacationer</p>
                                    </div>
                                </div>
                                
                                <div class="carousel-item">
                                    <div class="text-center">
                                        <img src="assets/img/testimonial-3.jpg" class="rounded-circle mb-3" width="80" height="80" alt="Customer Testimonial">
                                        <p class="lead">"As someone who travels frequently alone, I appreciate how HotelHaven shows detailed safety information and neighborhood details. It's been my go-to for the past year."</p>
                                        <div class="d-flex justify-content-center mt-3">
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="fas fa-star text-warning"></i>
                                            <i class="far fa-star text-warning"></i>
                                        </div>
                                        <h5 class="mt-2 mb-0">Elena Rodriguez</h5>
                                        <p class="text-muted small">Solo Traveler</p>
                                    </div>
                                </div>
                            </div>
                            
                            <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Newsletter Section -->
<div class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto text-center">
            <h2>Subscribe to Our Newsletter</h2>
            <p class="mb-4 text-muted">Stay updated with the latest hotel deals, travel tips, and exclusive offers.</p>
            
            <form class="row g-3 justify-content-center">
                <div class="col-md-8">
                    <input type="email" class="form-control" placeholder="Your email address" required>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100">Subscribe</button>
                </div>
            </form>
            
            <p class="mt-3 small text-muted">We respect your privacy. Unsubscribe at any time.</p>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
